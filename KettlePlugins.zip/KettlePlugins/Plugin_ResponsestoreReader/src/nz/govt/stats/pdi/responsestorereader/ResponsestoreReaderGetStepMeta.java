package nz.govt.stats.pdi.responsestorereader;

/*
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
*/
import org.apache.commons.lang3.StringUtils;
import org.pentaho.di.core.CheckResult;
import org.pentaho.di.core.CheckResultInterface;
import org.pentaho.di.core.annotations.Step;
import org.pentaho.di.core.database.DatabaseMeta;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.exception.KettleStepException;
import org.pentaho.di.core.exception.KettleValueException;
import org.pentaho.di.core.exception.KettleXMLException;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.core.row.ValueMetaInterface;
import org.pentaho.di.core.row.value.ValueMetaBase;
import org.pentaho.di.core.variables.VariableSpace;
import org.pentaho.di.core.xml.XMLHandler;
import org.pentaho.di.i18n.BaseMessages;
import org.pentaho.di.repository.ObjectId;
import org.pentaho.di.repository.Repository;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.*;
import org.pentaho.metastore.api.IMetaStore;
import org.w3c.dom.Node;

//import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.List;

/**
 * This interface allows custom steps to talk to Kettle. The StepMetaInterface is the main Java 
 * interface that a plugin implements. The responsibilities of the implementing class are listed below:
 * - Provide instances of other plugin classes (dialog, data and step processing
 * - Serialising data for the configuration
 * - Reporting the input and output fields for the step (getFields)
 * - Validating settings
 * @author mdean
 *
 */
@Step(
        id="ResponseStoreReader",
        image = "nz/govt/stats/pdi/responsestorereader/resources/icon.png",
        i18nPackageName = "nz.govt.stats.pdi.responsestorereader",
        name = "ResponsestoreReader.Name",
        description = "StatsNZ Response Store Reader",
        categoryDescription = "i18n:org.pentaho.di.trans.step:BaseStep.Category.Input"
)
public class ResponsestoreReaderGetStepMeta extends BaseStepMeta implements StepMetaInterface {

    private static Class<?> PKG = ResponsestoreReaderGetStepMeta.class; // for i18n purposes

    private final static String KEY_URL = "url";
    private final static String KEY_COLLECTION_NAME = "collection_name";
    private final static String KEY_COLLECTION_INSTANCE_ID = "collection_instance_id";
    private final static String KEY_START_DATE = "start_date"; 
    private final static String KEY_END_DATE = "end_date"; 
    
    private final static String KEY_USE_INTEGRATED_SECURITY = "use_integrated_security";
    
    private final static String KEY_OUTPUT_FIELDS = "output_fields";

    private final static String KEY_OUTPUT_FIELD = "output_field";

    private final static String KEY_OUTPUT_FIELD_NAME = "name";
    
    private final static String KEY_OUTPUT_FIELD_TYPE = "type";
    
    private String url;
    private String collectionName;
    private String collectionInstanceCode;
    private String startDate; 
    private String endDate;
    
    private boolean useIntegratedSecurity;
       
	private List<DatasetField> outputFields = new ArrayList<DatasetField>();
    
    public ResponsestoreReaderGetStepMeta() {
        super();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setUrlIfPresent(String value) {
        if (StringUtils.isNotBlank(value)) {
            setUrl(value);
        }
    }
    

    public String getCollectionInstanceCode() {
        return collectionInstanceCode;
    }

    public void setCollectionInstanceCode(String where) {
        this.collectionInstanceCode = where;
    }
    
    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String where) {
        this.startDate = where;
    }
    
    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String where) {
        this.endDate = where;
    }

    public boolean getUseIntegratedSecurity() {
        return useIntegratedSecurity;
    }
       
    public void setUseIntegratedSecurity(Boolean value) {
        this.useIntegratedSecurity = value;
    }


    public String getCollectionName() {
        return collectionName;
    }

    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }
    
    public List<DatasetField> getOutputFields() {
    	return outputFields;
    }
    
    public void setOutputFields(List<DatasetField> outputFields) {
    	this.outputFields = outputFields;
    }
    
    /**
     * Return a step processing class
     */
    @Override
    public StepInterface getStep(StepMeta stepMeta, StepDataInterface stepDataInterface, int cnr, TransMeta transMeta, Trans disp) {
        return new ResponsestoreReaderGetStep(stepMeta, stepDataInterface, cnr, transMeta, disp);
    }

    /**
     * Return instance data for this class
     */
    @Override
    public StepDataInterface getStepData() {
        return new ResponsestoreReaderGetStepData();
    }

    /**
     * Create sensible defautls
     */
    @Override
    public void setDefault() {
//        setUrl(" ");
        setCollectionName("");
        setCollectionInstanceCode("");
        setStartDate("");
        setEndDate("");
        setUseIntegratedSecurity(true);
        
    }

    @Override
    public Object clone() {
        return super.clone();
    }

    /**
     * Serialising the plugin configuration for storage in the transformation.xml
     */
    @Override
    public String getXML() throws KettleValueException {
        StringBuilder xml = new StringBuilder();

        xml.append(XMLHandler.addTagValue(KEY_URL, getUrl()));
        xml.append(XMLHandler.addTagValue(KEY_COLLECTION_NAME, getCollectionName()));
        xml.append(XMLHandler.addTagValue(KEY_COLLECTION_INSTANCE_ID, getCollectionInstanceCode()));
        xml.append(XMLHandler.addTagValue(KEY_START_DATE, getStartDate()));
        xml.append(XMLHandler.addTagValue(KEY_END_DATE, getEndDate()));
        xml.append(XMLHandler.addTagValue(KEY_USE_INTEGRATED_SECURITY, getUseIntegratedSecurity()?"Y":"N"));
        
        xml.append( XMLHandler.openTag( KEY_OUTPUT_FIELDS ) );
        System.out.println("fields="+outputFields.size());
        for (DatasetField field : outputFields) {
          xml.append( XMLHandler.openTag( KEY_OUTPUT_FIELD ) );
          xml.append( XMLHandler.addTagValue( KEY_OUTPUT_FIELD_NAME, field.getName() ) );
          xml.append( XMLHandler.addTagValue( KEY_OUTPUT_FIELD_TYPE, field.getType() ) );
          xml.append( XMLHandler.closeTag( KEY_OUTPUT_FIELD ) );
        }
        xml.append( XMLHandler.closeTag( KEY_OUTPUT_FIELDS ) );
        return xml.toString();
    }

    /**
     * Unserialising the plugin configuration from the transformation.xml
     */
    @Override
    public void loadXML(Node stepnode, List<DatabaseMeta> databases, IMetaStore metaStore) throws KettleXMLException {
        try {
            setUrlIfPresent(XMLHandler.getNodeValue(XMLHandler.getSubNode(stepnode, KEY_URL)));
            setCollectionName(XMLHandler.getNodeValue(XMLHandler.getSubNode(stepnode, KEY_COLLECTION_NAME)));
            setCollectionInstanceCode(XMLHandler.getNodeValue(XMLHandler.getSubNode(stepnode, KEY_COLLECTION_INSTANCE_ID)));
            setStartDate(XMLHandler.getNodeValue(XMLHandler.getSubNode(stepnode, KEY_START_DATE))); 
            setEndDate(XMLHandler.getNodeValue(XMLHandler.getSubNode(stepnode, KEY_END_DATE))); // 
            setUseIntegratedSecurity(XMLHandler.getNodeValue(XMLHandler.getSubNode(stepnode, KEY_USE_INTEGRATED_SECURITY)).equals("Y"));            
            
            List<Node> ofs = XMLHandler.getNodes( XMLHandler.getSubNode(stepnode, KEY_OUTPUT_FIELDS), KEY_OUTPUT_FIELD);
            for (Node n : ofs) {
            	String name = XMLHandler.getTagValue(n, KEY_OUTPUT_FIELD_NAME);
    			int type = Integer.parseInt(XMLHandler.getTagValue(n, KEY_OUTPUT_FIELD_TYPE));
    			outputFields.add(new DatasetField(name, type));
            }
            
        } catch (Exception e) {
            throw new KettleXMLException("unable to read the step's configuration from xml", e);
        }
    }

    /**
     * Serialising the configuration for storage in the repository (we don't use this)
     */
    @Override
    public void saveRep(Repository rep, IMetaStore metaStore, ObjectId id_transformation, ObjectId id_step) throws KettleException {
        try {
            rep.saveStepAttribute(id_transformation, id_step, KEY_URL, getUrl());
            rep.saveStepAttribute(id_transformation, id_step, KEY_COLLECTION_NAME, getCollectionName());
            rep.saveStepAttribute(id_transformation, id_step, KEY_COLLECTION_INSTANCE_ID, getCollectionInstanceCode());
            rep.saveStepAttribute(id_transformation, id_step, KEY_START_DATE, getStartDate());
            rep.saveStepAttribute(id_transformation, id_step, KEY_END_DATE, getEndDate());
            rep.saveStepAttribute(id_transformation, id_step, KEY_USE_INTEGRATED_SECURITY, (getUseIntegratedSecurity()?"Y":"N"));
            
            // TODO: output fields storage
            
        } catch (Exception e) {
            throw new KettleException("Unable to save step into repository: " + id_step, e);
        }
    }

    /**
     * Unserialising the configuration from the repository (we don't use this)
     */
    @Override
    public void readRep(Repository rep, IMetaStore metaStore, ObjectId id_step, List<DatabaseMeta> databases) throws KettleException {
        try {
            setUrlIfPresent(rep.getStepAttributeString(id_step, KEY_URL));
            setCollectionName(rep.getStepAttributeString(id_step, KEY_COLLECTION_NAME));
            setCollectionInstanceCode(rep.getStepAttributeString(id_step, KEY_COLLECTION_INSTANCE_ID));
            setStartDate(rep.getStepAttributeString(id_step, KEY_START_DATE));
            setEndDate(rep.getStepAttributeString(id_step, KEY_END_DATE));
            setUseIntegratedSecurity(rep.getStepAttributeBoolean(id_step, KEY_USE_INTEGRATED_SECURITY));
            
            
            // TODO: output fields storage
            
        } catch (Exception e) {
            throw new KettleException("Unable to load step from repository", e);
        }
    }

    /**
     * Set the columns and its type
     */
    @Override
    public void getFields(
            RowMetaInterface inputRowMeta,
            String name,
            RowMetaInterface[] info,
            StepMeta nextStep,
            VariableSpace space,
            Repository repository,
            IMetaStore metaStore) throws KettleStepException {

    	// Response Id
    	ValueMetaInterface rid = new ValueMetaBase("ResponseId",ValueMetaBase.TYPE_STRING);
    	rid.setTrimType(ValueMetaBase.TRIM_TYPE_BOTH);
    	rid.setOrigin(name);
    	inputRowMeta.addValueMeta(rid);
    	
    	// uoi
    	ValueMetaInterface uoi = new ValueMetaBase("Uoi",ValueMetaBase.TYPE_STRING);
    	uoi.setTrimType(ValueMetaBase.TRIM_TYPE_BOTH);
    	uoi.setOrigin(name);
    	inputRowMeta.addValueMeta(uoi);
    	
    	// instrument
    	ValueMetaInterface instrument = new ValueMetaBase("Instrument",ValueMetaBase.TYPE_STRING);
    	instrument.setTrimType(ValueMetaBase.TRIM_TYPE_BOTH);
    	instrument.setOrigin(name);
    	inputRowMeta.addValueMeta(instrument);
    	
    	// collection-instance
    	ValueMetaInterface ci = new ValueMetaBase("CollectionInstance",ValueMetaBase.TYPE_STRING);
    	ci.setTrimType(ValueMetaBase.TRIM_TYPE_BOTH);
    	ci.setOrigin(name);
    	inputRowMeta.addValueMeta(ci);
    	
    	// id
    	ValueMetaInterface id = new ValueMetaBase("Id",ValueMetaBase.TYPE_STRING);
    	id.setTrimType(ValueMetaBase.TRIM_TYPE_BOTH);
    	id.setOrigin(name);
    	inputRowMeta.addValueMeta(id);
    	
    	// data
    	ValueMetaInterface data = new ValueMetaBase("Data",ValueMetaBase.TYPE_STRING);
    	data.setTrimType(ValueMetaBase.TRIM_TYPE_BOTH);
    	data.setOrigin(name);
    	inputRowMeta.addValueMeta(data);

    }

    /**
     * Check the configuration
     */
    @Override
    public void check(
            List<CheckResultInterface> remarks,
            TransMeta transMeta,
            StepMeta stepMeta,
            RowMetaInterface prev,
            String input[],
            String output[],
            RowMetaInterface info,
            VariableSpace space,
            Repository repository,
            IMetaStore metaStore) {

        if (StringUtils.isBlank(url)) {
            remarks.add(new CheckResult(
                    CheckResult.TYPE_RESULT_ERROR,
                    BaseMessages.getString(PKG, "ResponsestoreReaderGetStep.CheckResult.URL.Required", ""),
                    stepMeta));
        }
       
        if (StringUtils.isBlank(collectionInstanceCode)) {
            remarks.add(new CheckResult(
                    CheckResult.TYPE_RESULT_ERROR,
                    BaseMessages.getString(PKG, "ResponsestoreReaderStep.CheckResult.CollectionInstanceCode.Required", ""),
                    stepMeta));        
        }
    }
    
    
    /**
     * Load the dataset definitions from the metadata API.
     */
    //TODO: add support for environment variable substitution.
}
