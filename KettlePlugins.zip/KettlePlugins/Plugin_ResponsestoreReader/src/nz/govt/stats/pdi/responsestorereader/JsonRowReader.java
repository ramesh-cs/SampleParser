package nz.govt.stats.pdi.responsestorereader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.ContentHandler;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.pentaho.di.core.exception.KettleException;

/**
 * Parse streaming JSON data from the datastore API to extract columns.
 * @author mdean
 *
 */
public class JsonRowReader {

    private final InputStreamReader reader;
    private JSONParser jsonParser;
    private boolean isInitialized;
    private JsonContentHandler contentHandler;
    private JSONObject nextObject;

    public JsonRowReader(final InputStream inputStream) {
        this.jsonParser = new JSONParser();
        this.contentHandler = new JsonContentHandler(this);
        this.reader = new InputStreamReader(inputStream);
        this.isInitialized = false;
        this.nextObject = null;        
    }
    
    /**
     * Parse the stream from the data API return the next row
     * @return null if no more data otherwise the row as a JSONObject.
     * @throws KettleException 
     */
    public JSONObject getNext() throws KettleException {
    	try {
    		if (!isInitialized) {
    			jsonParser.parse(reader, this.contentHandler, false);
    			isInitialized = true;
    		} else {
    			jsonParser.parse(reader, this.contentHandler, true);
    		}
    		
    		return this.nextObject;
    	} catch (ParseException e) {
    		throw new KettleException("Unable to parse data", e);
    	} catch (IOException e ) {
    		System.out.println("Exception occurred "+ e.getMessage());
    		return null;
    	}
    }
    
    /**
     * Implementation of parsing looking for the start and end of row objects in
     * the stream.
     */
    class JsonContentHandler implements ContentHandler {
    	private JsonRowReader parent;
    	
    	JsonContentHandler(JsonRowReader parent) {
    		this.parent = parent;
    	}
    	
		@Override
		public boolean endArray() throws ParseException, IOException {
			this.parent.nextObject = null;
			return false; // stop parsing (only works with one object per row)
		}

		@Override
		public void endJSON() throws ParseException, IOException {
	    	this.parent.nextObject = null;
		}

		@Override
		public boolean endObject() throws ParseException, IOException {
			return false; // stop parsing
		}

		@Override
		public boolean endObjectEntry() throws ParseException, IOException {
			return true; // keep parsing
		}

		@Override
		public boolean startArray() throws ParseException, IOException {
			return true; // keep parsing
		}

		@Override
		public void startJSON() throws ParseException, IOException {
		}

		@Override
		public boolean startObject() throws ParseException, IOException {
			this.parent.nextObject = new JSONObject();
			return true;
		}

		private String objectEntryKey = null;
		
		@Override
		public boolean startObjectEntry(String objectEntryValue) throws ParseException,
				IOException {
			this.objectEntryKey = objectEntryValue;
			return true; // keep parsing
		}		
		
		@SuppressWarnings("unchecked")
		@Override
		public boolean primitive(Object objectEntryValue) throws ParseException,
				IOException {
			this.parent.nextObject.put(objectEntryKey, objectEntryValue);
			return true; // keep parsing
		}
    }
}