package nz.govt.stats.pdi.responsestorereader;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
//import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.row.RowDataUtil;
import org.pentaho.di.core.row.RowMeta;
import org.pentaho.di.core.row.RowMetaInterface;
//import org.pentaho.di.core.row.value.ValueMetaBase;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.*;

import java.io.*;
/*
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
*/

/**
 * This class implements the row processing for the step. It initiates a connection to the response
 * api to read the specified survey.
 * @author mdean
 *
 */
public class ResponsestoreReaderGetStep extends BaseStep implements StepInterface {

    private JsonRowReader rowReader;

    /**
     * Default constructor
     * @param stepMeta a reference to this step's configuration
     * @param stepDataInterface defines the basic interface for the data used by a thread. This will allow us to stop execution of threads and restart them later on without loosing track of the situation. Typically the StepDataInterface implementing class will contain result sets, temporary data, caching indexes, etc.
     * @param copyNr if multiple copies of this instance of the step are running (i.e. multi-threaded) this is the thread number
     * @param transMeta
     * @param dis
     */
    public ResponsestoreReaderGetStep(
            StepMeta stepMeta,
            StepDataInterface stepDataInterface,
            int copyNr,
            TransMeta transMeta,
            Trans dis) {
        super(stepMeta, stepDataInterface, copyNr, transMeta, dis);
    }

    /**
     * Open a connection to the data api service. Use integrated security if
     * @param meta a reference to the step's data storage.
     * @return a HttpEntity for the response or null if the API call was invalid
     * @throws KettleException on connection error
     */
    HttpEntity openConnection(ResponsestoreReaderGetStepMeta meta) throws KettleException  {
        StringBuilder url = new StringBuilder(environmentSubstitute(StringUtils.trimToEmpty(meta.getUrl())));

        if (0 == url.length()) {
            throw new KettleException("the responsestore url must be supplied");
        }
        // TODO: Need to cope with hostnames that end in a '/'
        //url.append("/statsnz-epl-data/api/v1/datasets/");
        //url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getDatasetName())));

        url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getCollectionName())));
        url.append("/");
        url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getCollectionInstanceCode())));
        url.append("/responses");

        String sdate = environmentSubstitute(StringUtils.trimToEmpty(meta.getStartDate()));
        String edate = environmentSubstitute(StringUtils.trimToEmpty(meta.getEndDate()));

        Boolean isParams =  !sdate.isEmpty() | !edate.isEmpty();

        if (isParams) url.append("?");

        // Add the start date if available
        if (!sdate.isEmpty())
        {
        	url.append("start=");
        	url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getStartDate())));
        	// Or
        	//url.append("/");
        	//url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getStartDate())));
        }
        
        // Add the end date if available
        if (!sdate.isEmpty() && !edate.isEmpty())
        {
            url.append("&");
            url.append("end=");
        	url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getEndDate())));
        	// Or
        	//url.append("/");
        	//url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getEndDate())));
        }else if (!edate.isEmpty()){

            url.append("end=");
            url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getEndDate())));
        }
        
        
        // Add the version number if available
        /*
        String version = environmentSubstitute(StringUtils.trimToEmpty(meta.getDatasetVersion()));
        if (!version.isEmpty())
        {
        	url.append("/");
        	url.append(environmentSubstitute(StringUtils.trimToEmpty(meta.getDatasetVersion())));
        }
        
    	String username = environmentSubstitute(StringUtils.trimToEmpty(meta.getUsername()));
    	String password = environmentSubstitute(StringUtils.trimToEmpty(meta.getPassword()));
    	CloseableHttpClient httpclient = HttpSupport.OpenConnection(meta.getUseIntegratedSecurity(), username, password);
    	*/
        //CloseableHttpClient httpclient = HttpClients.createDefault();
        CloseableHttpClient httpclient = HttpSupport.OpenConnection(meta.getUseIntegratedSecurity());
        	
        try {
            HttpGet httpget = new HttpGet(url.toString());
            httpget.addHeader("accept", "application/json-stream");
            
            logBasic("Executing request " + httpget.getRequestLine());
            CloseableHttpResponse response = httpclient.execute(httpget);
            logBasic("Response " + response.getStatusLine());

            // TODO: handle failures here
            if (response.getStatusLine().getStatusCode() != 200) {
            	throw new KettleException("url: " +url.toString()+" Unable to access responsestore. Catch 1" + " Status code: "+response.getStatusLine().getStatusCode());
            }
           
            return response.getEntity(); 
        } catch (ClientProtocolException e) {
			logError("ClientProtocolException: Unable to initialize the step ", e.getMessage());
        	throw new KettleException("url: " + url.toString()+ " Unable to access responsestore. Catch 2");
		} catch (IOException e) {
			logError("IOException: Unable to initialize the step", e.getMessage());
        	throw new KettleException("url: " + url.toString()+ " Unable to access responsestore. Catch 3");
		}
    }
    
    /**
     * When the transformation is executed, this method is called first. We open the 
     * connection to the responsestore API here and create a parser for the response data.
     * The repsonse data
     */
    @Override
    public boolean init(StepMetaInterface smi, StepDataInterface sdi) {
        ResponsestoreReaderGetStepMeta meta = (ResponsestoreReaderGetStepMeta) smi;
        ResponsestoreReaderGetStepData data = (ResponsestoreReaderGetStepData) sdi;
        boolean result = false;

        try {
        	data.setHttpEntityMessage(openConnection(meta));

            try {
            	rowReader = new JsonRowReader(data.getHttpEntityMessage().getContent());
                result = true;
            } catch (Exception ioe) {
                throw new KettleException("Unable to read responsestore", ioe);
            }

        } catch (KettleException ke) {
            logError("Unable to initialize the step", ke);
        }

        return result && super.init(smi, sdi);
    }
    
    /**
     * This method is called for each row the plugin receives. It'll be called once if this step is
     * not connected to any other steps.
     */
    @Override
    public boolean processRow(StepMetaInterface smi, StepDataInterface sdi) throws KettleException {
    	ResponsestoreReaderGetStepMeta meta = (ResponsestoreReaderGetStepMeta) smi;
    	ResponsestoreReaderGetStepData data = (ResponsestoreReaderGetStepData) sdi;

        if (first) {
            first = false;
            RowMetaInterface outputRowMeta = new RowMeta();
            meta.getFields(outputRowMeta, getStepname(), null, null, this, null, null);
            data.setOutputRowMeta(outputRowMeta);
        }
        
        // TODO: What happens if JSON is inside of the columns? Will the parser explode
        // TODO: Handle HTTP charsets
        JSONObject row = rowReader.getNext();

        if (null != row) {
        	Object[] outputRow = RowDataUtil.allocateRowData(6);
        	
        	outputRow[0] = row.get("response-id").toString();
        	outputRow[1] = row.get("uoi").toString();
        	outputRow[2] = row.get("instrument").toString();
        	outputRow[3] = row.get("collection-instance").toString();
        	outputRow[4] = row.get("id").toString();
        	outputRow[5] = row.get("data").toString();
        	
        	
        	/* Delete below commented code once above code start working
        	List<DatasetField> fields = meta.getOutputFields();
            for (int i = 0; i < fields.size(); i++) {
            	DatasetField field = fields.get(i);
            	Object cell = row.get(field.getName());
            	if (field.getType() == ValueMetaBase.TYPE_DATE) {
            		SimpleDateFormat fmt= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
            		try {
            			outputRow[i] = fmt.parse(cell.toString());
            		} catch (ParseException e) {
            			throw new KettleException("Unable to parse date in dataset", e);
            		}
            	} else {
            		outputRow[i] = cell;
            	}
            }
            */
        	
            putRow(data.getOutputRowMeta(), outputRow);
            incrementLinesOutput();
            return true;
        }

        setOutputDone();
        return false;
    }

    /**
     * Clean up and destroy the HttpClient if it is not already closed.
     */
    @Override
    public void dispose(StepMetaInterface smi, StepDataInterface sdi) {
    	ResponsestoreReaderGetStepMeta meta = (ResponsestoreReaderGetStepMeta) smi;
    	ResponsestoreReaderGetStepData data = (ResponsestoreReaderGetStepData) sdi;

        HttpEntity entity = data.getHttpEntityMessage();
        if (entity != null) {
        	try {
        		InputStream inputStream = entity.getContent();
        		if (inputStream != null) {
                	inputStream.close();
                	logBasic("Closing datastore reader connection");        		
        		}
        	} catch (IOException e) {
                logError("Unable to close datastore reader connection", e);        		
        	}
        }
        
        super.dispose(meta, data);
    }

}
