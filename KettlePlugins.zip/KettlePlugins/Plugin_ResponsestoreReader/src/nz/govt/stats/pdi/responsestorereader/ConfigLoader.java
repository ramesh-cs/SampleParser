package nz.govt.stats.pdi.responsestorereader;



import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/**
 * Created by rsivaram on 18/01/2017.
 */
public class ConfigLoader {


    public Properties getConfigurations(){
        URL path = ConfigLoader.class.getProtectionDomain().getCodeSource().getLocation();
        String pathToConfig = path.getPath();
        String stripedString = StringUtils.stripStart(pathToConfig, "/");
        File file = null;
        file = new File(stripedString);

        List<File> listOfFiles = Collections.EMPTY_LIST;
        Properties props = null;
//        File file = null;
//        try {
//            String decodedURL = URLDecoder.decode(path.getPath(), "UTF-8");
//            Path parent = Paths.get(decodedURL).getParent();
//            file = new File(parent.toUri());
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }
        File parentFolder = getDirectory(new File(file.getParent()));

        if (parentFolder != null){

            listOfFiles = Arrays.asList(parentFolder.listFiles());
        }

        if (listOfFiles != null && !listOfFiles.isEmpty()){

            for (File singleFile : listOfFiles) {
                if (!singleFile.isFile() && singleFile.getName().equalsIgnoreCase("conf")) {

//                    System.out.println("SNZRestClientPlugin: Found config file" );
                    props = loadProperties(singleFile);
                }
            }
        }
        return props;
    }
    private static File getDirectory(File file){

        if(!file.isDirectory()){
            return getDirectory(new File(file.getParent()));
        }
        return file;
    }

    private Properties loadProperties(File config){

        List<File> configs = Arrays.asList(config.listFiles());
        Properties props = new Properties();
//        System.out.println("SNZRestClientPlugin: reached loadProperties, number of files in config - " + configs.size());
//        System.out.println(" SNZRestClientPlugin: Path: " + config.getAbsolutePath());
        if (configs.size() > 0)
        {
            File propsFile  = configs.get(0);
//            System.out.println(" SNZRestClientPlugin: config file abs path" + propsFile.getAbsolutePath());

            InputStream propsStream = null;
            try {
                propsStream = new FileInputStream(propsFile);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            try {
                props.load(propsStream);
            } catch (IOException e) {
                e.printStackTrace();
            }

            String url = props.getProperty("Read.Store.URL");
        }
        return props;
    }
}
