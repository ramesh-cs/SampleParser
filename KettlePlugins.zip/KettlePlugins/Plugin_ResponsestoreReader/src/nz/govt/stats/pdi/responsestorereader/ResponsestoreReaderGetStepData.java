package nz.govt.stats.pdi.responsestorereader;

import org.apache.http.HttpEntity;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.trans.step.BaseStepData;
import org.pentaho.di.trans.step.StepDataInterface;

/**
 * Instance data for this step.
 * @author mdean
 *
 */
public class ResponsestoreReaderGetStepData extends BaseStepData implements StepDataInterface {

    private RowMetaInterface outputRowMeta;

    private HttpEntity httpEntity = null;

    public ResponsestoreReaderGetStepData() {
        super();
    }

    public void setOutputRowMeta(RowMetaInterface outputRowMeta) {
        this.outputRowMeta = outputRowMeta;
    }

    public RowMetaInterface getOutputRowMeta() {
        return outputRowMeta;
    }

    public void setHttpEntityMessage(HttpEntity httpEntity) {
        this.httpEntity = httpEntity;
    }

    public HttpEntity getHttpEntityMessage() {
        return httpEntity;
    }

}

