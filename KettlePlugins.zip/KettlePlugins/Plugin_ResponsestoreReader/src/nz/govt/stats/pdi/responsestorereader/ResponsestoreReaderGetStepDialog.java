package nz.govt.stats.pdi.responsestorereader;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.*;
import org.pentaho.di.core.Const;
import org.pentaho.di.i18n.BaseMessages;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.ui.core.widget.ComboVar;
import org.pentaho.di.ui.core.widget.TextVar;
import org.pentaho.di.ui.trans.step.BaseStepDialog;
import org.pentaho.di.trans.step.BaseStepMeta;
import org.pentaho.di.trans.step.StepDialogInterface;

import java.util.*;

/**
 * The implementation of the configuration dialog for this step
 * @author mdean
 *
 */
// this will allow the transformation to show the columns to subsequent steps.
public class ResponsestoreReaderGetStepDialog extends BaseStepDialog implements StepDialogInterface {

    private static Class<ResponsestoreReaderGetStepMeta> PKG = ResponsestoreReaderGetStepMeta.class; // for i18n purposes

    private ResponsestoreReaderGetStepMeta meta;

    private TextVar wCollectionName;
      
    private TextVar wCollectionInstanceID;
    private TextVar wStartDate;
    private TextVar wEndDate;
    private Button  wUseIntegratedSecurity;
    private ComboVar wEnvironment;
    private Map<String, String> environments;
    
    public ResponsestoreReaderGetStepDialog(Shell parent, Object in, TransMeta transMeta, String sname) {
        super(parent, (BaseStepMeta) in, transMeta, sname);
        meta = (ResponsestoreReaderGetStepMeta) in;
        environments = new HashMap<>();
    }

    /**
     * Create a label for a field
     * @param composite the dialog window
//     * @param key the label text
     * @param formData the form to place the label in
     * @return
     */
    private Label createStandardLabel(Composite composite, String text, FormData formData) {
        Label label = new Label(composite, SWT.RIGHT);
        label.setText(BaseMessages.getString(PKG, text, ""));
        props.setLook(label);
        label.setLayoutData(formData);
        return label;
    }

    /**
     * Create a checkbox with no label.
     * @param composite the dialog window
//     * @param key the checkbox text
     * @param formData the form to place the label in
     * @return
     */

    private Button createStandardCheckbox(Composite composite, String text, FormData formData, Listener checkboxListener) {
        Button result = new Button(composite, SWT.CHECK);
        result.setText(text);
        props.setLook(result);
        result.setLayoutData(formData);
        return result;
    }

    /**
     * This method creates a text field entry without pentaho environment variable substitution.
     * @param composite the dialog window
     * @param initialValue the initial text to show in the text field
     * @param formData the form to place the label in
     * @param modifyListener
     * @return
     */
    private Text createStandardText(Composite composite, String initialValue, FormData formData, ModifyListener modifyListener) {
        Text result = new Text(composite, SWT.SINGLE | SWT.LEFT | SWT.BORDER);
        result.setText(initialValue);
        props.setLook(result);
        result.addModifyListener(modifyListener);
        result.setLayoutData(formData);
        return result;
    }

    /**
     * This method creates a text field entry that supports pentaho environment variable substitution.
     * @param composite the dialog window
     * @param initialValue the initial text to show in the text field
     * @param formData the form to place the label in
     * @param modifyListener
     * @return
     */
    private TextVar createStandardTextVar(Composite composite, String initialValue, FormData formData, ModifyListener modifyListener) {
        TextVar result = new TextVar(transMeta, composite, SWT.SINGLE | SWT.LEFT | SWT.BORDER);
        result.setText(initialValue);
        props.setLook(result);
        result.addModifyListener(modifyListener);
        result.setLayoutData(formData);
        return result;
    }

    private ComboVar createStandardComboVar(Composite composite, String initialValue, FormData formData, ModifyListener modifyListener) {
        ComboVar result = new ComboVar(transMeta, composite, SWT.BORDER | SWT.READ_ONLY);
        result.setEditable( false );
        props.setLook(result);
        result.addModifyListener(modifyListener);
        result.setLayoutData(formData);
        result.addSelectionListener( new SelectionAdapter() {

            public void widgetSelected( SelectionEvent e ) {
                meta.setChanged();
            }
        } );
//        result.setItems( new String[] {"XML", "JSON"} );
        result.setItems(getEnvironmentChoices());
        return result;
    }

    private FormData createStandardLabelFormData(Control lastControl) {
        FormData ds = new FormData();
        ds.left = new FormAttachment(0, 0);
        ds.right = new FormAttachment(props.getMiddlePct(), -Const.MARGIN);

        if (null == lastControl) {
            ds.top = new FormAttachment(0, Const.MARGIN);
        } else {
            ds.top = new FormAttachment(lastControl, Const.MARGIN);
        }

        return ds;
    }

    private FormData createStandardControlFormData(Control lastControl) {
        FormData ds = new FormData();
        ds.left = new FormAttachment(props.getMiddlePct(), 0);
        ds.right = new FormAttachment(100, 0);

        if (null == lastControl) {
            ds.top = new FormAttachment(0, Const.MARGIN);
        } else {
            ds.top = new FormAttachment(lastControl, Const.MARGIN);
        }

        return ds;
    }

    /**
     * Create the configuration dialog box
     */
    public String open() {
        Shell parent = getParent();
        Display display = parent.getDisplay();

        shell = new Shell(parent, SWT.DIALOG_TRIM | SWT.RESIZE | SWT.MIN | SWT.MAX);
        props.setLook(shell);
        setShellImage(shell, meta);

        changed = meta.hasChanged();

        ModifyListener lsMod = new ModifyListener() {
            public void modifyText(ModifyEvent e) {
                meta.setChanged();
            }
        };
        

        Listener lsCheckboxMod = new Listener() {
        	public void handleEvent(Event e) {
        		 meta.setChanged();
            }
        };

        FormLayout formLayout = new FormLayout();
        formLayout.marginWidth = Const.FORM_MARGIN;
        formLayout.marginHeight = Const.FORM_MARGIN;

        shell.setLayout(formLayout);
        shell.setText(BaseMessages.getString(PKG, "ResponsestoreReader.Shell.Title", "")+ " Version: " + BaseMessages.getString(PKG, "ResponsestoreReader.Shell.Version", ""));

        int margin = Const.MARGIN;

        Control lastControl = null;

        {
            fdlStepname = createStandardLabelFormData(lastControl); // not sure why it keeps this?
            wlStepname = createStandardLabel(shell, "System.Label.StepName", fdlStepname);
            wStepname = createStandardText(shell, stepname, createStandardControlFormData(lastControl), lsMod);
            lastControl = wStepname;
        }

        //New choice box to select environments
        {
            createStandardLabel(shell, "ResponsestoreReader.Environment", createStandardLabelFormData(lastControl));
            wEnvironment = createStandardComboVar(shell, "", createStandardControlFormData(lastControl), lsMod);
            lastControl = wEnvironment;
        }

        {
            createStandardLabel(shell, "ResponsestoreReader.CollectionName", createStandardLabelFormData(lastControl));
            wCollectionName = createStandardTextVar(shell, "", createStandardControlFormData(lastControl), lsMod);
            lastControl = wCollectionName;
        }
                       
        {
        	createStandardLabel(shell, "ResponsestoreReader.CollectionInstance.Code", createStandardLabelFormData(lastControl));
            wCollectionInstanceID = createStandardTextVar(shell, "", createStandardControlFormData(lastControl), lsMod);
            lastControl = wCollectionInstanceID;
        }

        
        {
        	createStandardLabel(shell, "ResponsestoreReader.StartDate.Title", createStandardLabelFormData(lastControl));
            wStartDate = createStandardTextVar(shell, "", createStandardControlFormData(lastControl), lsMod);
            lastControl = wStartDate;
        }
        
        {
        	createStandardLabel(shell, "ResponsestoreReader.EndDate.Title", createStandardLabelFormData(lastControl));
            wEndDate = createStandardTextVar(shell, "", createStandardControlFormData(lastControl), lsMod);
            lastControl = wEndDate;
        }
        {
            createStandardLabel(shell, "ResponsestoreReader.UseIntegratedSecurity.Title", createStandardLabelFormData(lastControl));
            wUseIntegratedSecurity = createStandardCheckbox(shell, "", createStandardControlFormData(lastControl), lsCheckboxMod);
            lastControl = wUseIntegratedSecurity;
        }
               
        // OK and cancel and get meta data buttons
        wOK = new Button(shell, SWT.PUSH);
        wOK.setText(BaseMessages.getString(PKG, "System.Button.OK", ""));
        wCancel = new Button(shell, SWT.PUSH);
        wCancel.setText(BaseMessages.getString(PKG, "System.Button.Cancel", ""));
        
        BaseStepDialog.positionBottomButtons(shell, new Button[]{wOK, wCancel}, margin, lastControl);

        // Add listeners for cancel and OK
        lsCancel = new Listener() {
            public void handleEvent(Event e) {
                cancel();
            }
        };
        lsOK = new Listener() {
            public void handleEvent(Event e) {
                ok();
            }
        };        

        wCancel.addListener(SWT.Selection, lsCancel);
        wOK.addListener(SWT.Selection, lsOK);

        // default listener (for hitting "enter")
        lsDef = new SelectionAdapter() {
            public void widgetDefaultSelected(SelectionEvent e) {
                ok();
            }
        };
        wStepname.addSelectionListener(lsDef);
        wCollectionName.addSelectionListener(lsDef);

        // Detect X or ALT-F4 or something that kills this window and cancel the dialog properly
        shell.addShellListener(new ShellAdapter() {
            public void shellClosed(ShellEvent e) {
                cancel();
            }
        });

        // Set/Restore the dialog size based on last position on screen
        // The setSize() method is inherited from BaseStepDialog
        setSize();

        // populate the dialog with the values from the meta object
        populateDialog();

        // restore the changed flag to original value, as the modify listeners fire during dialog population
        meta.setChanged(changed);

        // open dialog and enter event loop
        shell.open();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch())
                display.sleep();
        }

        // at this point the dialog has closed, so either ok() or cancel() have been executed
        // The "stepname" variable is inherited from BaseStepDialog
        return stepname;
    }

    /**
     * Populate the dialog with the step configuration.
     */
    private void populateDialog() {
        wStepname.selectAll();
        if (meta.getUrl() != null && !meta.getUrl().isEmpty()){

            for (String currentKey :environments.keySet()) {
                if(environments.get(currentKey).equalsIgnoreCase(meta.getUrl())){

                    wEnvironment.setText(StringUtils.trimToEmpty(currentKey));
                }
            }
        }

        wCollectionName.setText(StringUtils.trimToEmpty(meta.getCollectionName()));
        wCollectionInstanceID.setText(StringUtils.trimToEmpty(meta.getCollectionInstanceCode()));
        wStartDate.setText(StringUtils.trimToEmpty(meta.getStartDate()));
        wEndDate.setText(StringUtils.trimToEmpty(meta.getEndDate()));
        wUseIntegratedSecurity.setSelection(meta.getUseIntegratedSecurity());
        
        // TODO: show output fields maybe? outputFields = meta.getOutputFields();
    }

    private String[] getEnvironmentChoices(){
        ConfigLoader loader = new ConfigLoader();
        Properties props = loader.getConfigurations();
        if (props.size() <= 0 ){

//            throw new KettleException("Please set environment variables..");
        }
        Object[] keys = props.stringPropertyNames().toArray();
        ArrayList<String> envKeys = new ArrayList<>();
        for (Object property: keys) {
            Object value = props.get(property);
            environments.put(property.toString(), value.toString());
            envKeys.add(property.toString());
        }
        return envKeys.toArray(new String[envKeys.size()]);
    }

    /**
     * Cancel button is pressed, close the dialog
     */
    private void cancel() {
        stepname = null;
        meta.setChanged(changed);
        dispose();
    }

    /**
     * Ok button is press save the changes to the step
     */
    private void ok() {
        stepname = wStepname.getText();
        meta.setCollectionName(wCollectionName.getText());
        String environmentChoice = wEnvironment.getText();
        meta.setUrl(environments.get(environmentChoice));

        meta.setCollectionInstanceCode(wCollectionInstanceID.getText());
        meta.setStartDate(wStartDate.getText());
        meta.setEndDate(wEndDate.getText());
        meta.setUseIntegratedSecurity(wUseIntegratedSecurity.getSelection());

        dispose();
    }
}
