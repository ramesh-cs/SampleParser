package nz.govt.stats.pdi.pdfaddressmatcher;

public class DatasetField {
	private int type;
	private String name;
	
	public DatasetField(String name, int type) {
		this.name = name;
		this.type = type;
	}
	
	String getName() {
		return name;
	}
	
	int getType() {
		return type;
	}
}
