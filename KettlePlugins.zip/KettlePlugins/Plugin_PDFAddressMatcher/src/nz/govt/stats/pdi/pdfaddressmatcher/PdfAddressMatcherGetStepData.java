package nz.govt.stats.pdi.pdfaddressmatcher;

import java.util.ArrayList;
import java.util.List;

import nz.govt.stats.pdi.pdfaddressmatcher.extensions.PRVariable;

import org.apache.http.HttpEntity;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.trans.step.BaseStepData;
import org.pentaho.di.trans.step.StepDataInterface;

/**
 * Instance data for this step.
 * @author mdean
 *
 */
public class PdfAddressMatcherGetStepData extends BaseStepData implements StepDataInterface {

    private RowMetaInterface outputRowMeta;
    
    private HttpEntity httpEntity = null;

    /**
	 * Initial count of columns.
	 */    
	private int rowCount;
    private int inputSize;
    private StringBuilder sbAddXml = new StringBuilder();

    private PRVariable[] inputFields;
	
	private PRVariable[] outputFields;
	private List<Object> rowsToWrite = new ArrayList<Object>();
	private Object[] fnames;
	
	
	// Get field names of input data
	public Object[] getFnames(){
		return fnames;
	}
	// Set field names of input data
	public void setFnames(Object[] fieldnames){
		this.fnames = fieldnames;
	}
	// get Concatenated addresses to make request xml 
    public StringBuilder getsbAddXml(){
    	return sbAddXml;
    }
	// Set Concatenated addresses to make request xml
    public void setsbAddXml(String Add){
    	this.sbAddXml.append(Add);
    }
    // Get number of rows read, to match with BatchSize. When equals to batchsize then call outputResultBatch()
    public int getRowCount() {
		return rowCount;
	}
    // increment row
	public void incrementRowCount() {
		this.rowCount = this.rowCount + 1;
	}

	

	public int getInputSize() {
		return inputSize;
	}
	public void setInputSize(int inputSize) {
		this.inputSize = inputSize;
	}
	// Get Input data selected into the dropdown box
	public PRVariable[] getInputFields() {
		return inputFields;
	}
	// Set Input data selected into the dropdown box
	public void setInputFields(PRVariable[] inputFields) {
		this.inputFields = inputFields;
	}
	// Get output data selected into the dropdown box
	public PRVariable[] getOutputFields() {
		return outputFields;
	}
	// Set output data selected into the dropdown box
	public void setOutputFields(PRVariable[] outputFields) {
		this.outputFields = outputFields;
	}
	// get input rows to write in output
	public List<Object> getRowsToWrite() {
		return rowsToWrite;
	}	
	// Set input rows so can be use to write in output
	public void setRowsToWrite(List<Object> row) {
		this.rowsToWrite.add(row);
	}
	// Reset variables for next batch run
	public void clearCache(){
		rowCount = 0;
		rowsToWrite.clear();
		sbAddXml.setLength(0);
	}
	
	// Generic methods of the class
	public PdfAddressMatcherGetStepData() {
        super();
    }

    public void setOutputRowMeta(RowMetaInterface outputRowMeta) {
        this.outputRowMeta = outputRowMeta;
    }

    public RowMetaInterface getOutputRowMeta() {
        return outputRowMeta;
    }

    public void setHttpEntityMessage(HttpEntity httpEntity) {
        this.httpEntity = httpEntity;
    }

    public HttpEntity getHttpEntityMessage() {
        return httpEntity;
    }

    
}

