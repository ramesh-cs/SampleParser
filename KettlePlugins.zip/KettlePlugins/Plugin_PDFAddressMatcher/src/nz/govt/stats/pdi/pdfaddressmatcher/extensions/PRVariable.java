package nz.govt.stats.pdi.pdfaddressmatcher.extensions;

public class PRVariable {
	public static final int TYPE_STRING = 0;// String

	private String pdfName;
	private String pentahoName;
	private Object value;
	private int type;
	
	/**
	 * Variable.
	 * 
	 * @param pdfName
	 * @param pentahoName
	 * @param type
	 * @param value
	 */
	public PRVariable(String pdfName, String pentahoName, int type, Object value) {
		this.pdfName = pdfName;
		this.pentahoName = pentahoName;
		this.value = value;
		this.type = type;
	}
	
	/**
	 * Variable.
	 * 
	 * @param rName
	 * @param pentahoName
	 * @param type
	 */
	public PRVariable(String rName, String pentahoName, int type) {
		this(rName, pentahoName, type, null);
	}
	
	/**
	 * Get value.
	 * 
	 * @return
	 */
	public Object getValue() {
		return value;
	}
	
	/**
	 * Set value.
	 * 
	 * @param value
	 */
	public void setValue(Object value) {
		this.value = value;
	}
	
	/**
	 * Get r name.
	 * 
	 * @return
	 */
	public String getpdfName() {
		return pdfName;
	}

	/**
	 * Get variable name in pentaho.
	 * 
	 * @return
	 */
	public String getPentahoName() {
		return pentahoName;
	}

	/**
	 * Get type of variable.
	 * 
	 * @return
	 */
	public int getType() {
		return type;
	}
	public String getTypeName()	{
		return "String";		
	}	
	
}
