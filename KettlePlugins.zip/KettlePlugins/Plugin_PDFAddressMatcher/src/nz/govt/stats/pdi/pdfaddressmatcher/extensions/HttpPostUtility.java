package nz.govt.stats.pdi.pdfaddressmatcher.extensions;

import java.io.IOException;
import java.net.HttpURLConnection;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.http.util.EntityUtils;

public class HttpPostUtility {
	private String requestJson;
	//private PostMethod httpMethod;
	private HttpPost postMethod;
	private CloseableHttpClient closeableClient;
	private String url;
	
	public HttpPostUtility(String url, String requestJson, CloseableHttpClient closeableClient){
		this.requestJson = requestJson;
		this.url = url;
		
		if (!WinHttpClients.isWinAuthAvailable()) {
            System.out.println("Integrated Win auth is not supported!!!");
        }
		this.closeableClient = closeableClient;//WinHttpClients.createDefault();
	}
	
	 public String execute() throws IOException {
		 	postMethod = new HttpPost(url);
	    	try{
		    	String response = "";
		    	//Set the content type for the request.
		       	ContentType contentType = ContentType.create("application/json", "UTF-8");
		    	
		       	//This entity holds the body of the request.
		    	HttpEntity entity = new StringEntity(requestJson, contentType);
		    			    	
		    	postMethod.setEntity(entity);
		        
		        // checks server's status code first
		        CloseableHttpResponse httpResponse = closeableClient.execute(postMethod);
		        
		        int status = httpResponse.getStatusLine().getStatusCode();
		        if (status == HttpURLConnection.HTTP_OK) {	  
		        	response = EntityUtils.toString(httpResponse.getEntity());		        	
		            //httpMethod.releaseConnection();
		        } else {        	     
		        	response = EntityUtils.toString(httpResponse.getEntity());
		        	postMethod.releaseConnection();
		            throw new IOException("Server returned non-OK status: " + status + "." + "Error Message: " + response);
		        }
		        return response;
	    	}
	    	finally{
	    		try{
	    			postMethod.releaseConnection();
	    		}
	    		catch(Exception ex){
	    			ex.printStackTrace();
	    		}
	    	}       
	    }
}
