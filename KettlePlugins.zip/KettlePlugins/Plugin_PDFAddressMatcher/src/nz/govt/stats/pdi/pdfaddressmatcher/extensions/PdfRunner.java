package nz.govt.stats.pdi.pdfaddressmatcher.extensions;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;

public class PdfRunner {

	
	
	/**
	 * Callback function for R engine.
	 */
	private PdfCallback callback;
	/**
	 * Input variables.
	 */
	private PRVariable[] inputVars;
	/**
	 * Output variables.
	 */
	private PRVariable[] outputVars;

	/**
	 * Constructor.
	 * 
	 * @param filePath
	 */
	public PdfRunner() {				
		this.callback = new PdfCallback(true);
	}

	

	/**
	 * Get output.
	 * 
	 * @return
	 */
	public String getOutput() {
		if (callback instanceof PdfCallback) {
			return ((PdfCallback) callback).getOutput();
		}
		return "empty";
	}

	public static String getUrl(){
		try{
			File file = new File("plugins/steps/SNZPDFAddressMatcher/plugin.xml");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(file);
			document.getDocumentElement().normalize();
			if (document.getElementsByTagName("apiUrl") == null){
				System.out.println("Configuration Error: apiUrl is missing from plugin.xml");
				return "";
			}
			return document.getElementsByTagName("apiUrl").item(0).getTextContent();
			//return "http://172.28.133.200/ocpu//library/base/R/do.call/json";
		}
		catch (Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	public static String getBatchStanFields(){
		try{
			File file = new File("plugins/steps/SNZPDFAddressMatcher/plugin.xml");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(file);
			document.getDocumentElement().normalize();
			if (document.getElementsByTagName("BatchStanFields") == null){
				System.out.println("Configuration Error: BatchStanFields is missing from plugin.xml");
				return "";
			}
			return document.getElementsByTagName("BatchStanFields").item(0).getTextContent();
			//return "http://172.28.133.200/ocpu//library/base/R/do.call/json";
		}
		catch (Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	public static Integer getBatchSize(){
		try{
			File file = new File("plugins/steps/SNZPDFAddressMatcher/plugin.xml");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(file);
			document.getDocumentElement().normalize();
			if (document.getElementsByTagName("BatchSize") == null){
				System.out.println("Configuration Error: BatchStanFields is missing from plugin.xml");
				return 0;
			}
			return Integer.parseInt(document.getElementsByTagName("BatchSize").item(0).getTextContent());
			
		}
		catch (Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	public String getValueByTagNameFromPluginXml(String xmlTag){
		try{
			File file = new File("plugins/steps/SNZPDFAddressMatcher/plugin.xml");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(file);
			document.getDocumentElement().normalize();
			if (document.getElementsByTagName(xmlTag) == null){
				System.out.println("Configuration Error: "+ xmlTag +" is missing from plugin.xml");
				return "";
			}
			return document.getElementsByTagName(xmlTag).item(0).getTextContent();
			
		}
		catch (Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	public static String getVersion(){
		try{
			File file = new File("plugins/steps/SNZPDFAddressMatcher/plugin.xml");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(file);
			document.getDocumentElement().normalize();
			if (document.getElementsByTagName("Version") == null){
				System.out.println("Configuration Error: Version is missing from plugin.xml");
				return "";
			}
			return document.getElementsByTagName("Version").item(0).getTextContent();
			
		}
		catch (Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	public static String getGrammar(){
		try{
			File file = new File("plugins/steps/SNZPDFAddressMatcher/plugin.xml");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(file);
			document.getDocumentElement().normalize();
			if (document.getElementsByTagName("Grammar") == null){
				System.out.println("Configuration Error: BatchStanFields is missing from plugin.xml");
				return "";
			}
			return document.getElementsByTagName("Grammar").item(0).getTextContent();			
		}
		catch (Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	private String getRequestJson(){
		
		JSONObject jsonobj = new JSONObject();
		
		JSONArray args = new JSONArray();
		
		PRVariable[] variables = this.inputVars;
		/*
		for(int i = 0; i < variables.length; i++)
		{
			//For each input variable add it's name and value to json object
			PRVariable var = variables[i];
			
			JSONObject varObj = new JSONObject();
			varObj.put("Name", var.getpdfName());
			varObj.put("Type", var.getTypeName());
			varObj.put("Value", var.getValue());
			args.add(varObj);
		}
		jsonobj.put("Args", args);
		*/
		return jsonobj.toJSONString();
	}
	
	/**
	 * Initialize column variables.
	 * 
	 * @param var
	 
	protected void initColumnVariable(PRColumnVariable var) {
		switch (var.getType()) {
		case PRVariable.TYPE_BOOLEAN:
			Boolean[] valueFrom = var.getValueColumn().toArray(
					new Boolean[var.getValueColumn().size()]);
			boolean[] value = new boolean[valueFrom.length];
			for (int i = 0; i < value.length; i++) {
				value[i] = valueFrom[i];
			}
			//re.assign(var.getrName(), value);
			break;
		case PRVariable.TYPE_NUMBER:
			Double[] valueFromD = var.getValueColumn().toArray(
					new Double[var.getValueColumn().size()]);
			double[] valueD = new double[valueFromD.length];
			for (int i = 0; i < valueD.length; i++) {
				valueD[i] = valueFromD[i];
			}
			//re.assign(var.getrName(), valueD);
			break;
		case PRVariable.TYPE_STRING:
//			re.assign(
//					var.getrName(),
//					var.getValueColumn().toArray(
//							new String[var.getValueColumn().size()]));
			break;
		default:
		}

	}
	*/


	/**
	 * Update output variables value.
	 */
	protected void setOutputVariables(String result) throws Exception {
		//RList list = ret.asList();
		for (PRVariable var : outputVars) {
			
			if (var == null) {
				throw new Exception("Unable to find one or more output variables. Check the names and try again.");
			}
			if (result == null)
				var.setValue(null);
			else
			{
				var.setValue(result);
			}
		}
	}

}
