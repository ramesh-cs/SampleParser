package nz.govt.stats.pdi.pdfaddressmatcher.extensions;

public class PdfCallback {
	private StringBuffer output;
	private boolean sysout;

	public PdfCallback(boolean sysout) {
		output = new StringBuffer();
		this.sysout = sysout;
	}

	public void rBusy( int arg1) {
		output.append("rBusy").append("\n");
		if (sysout) {
			System.out.println("PdfBusy");
		}
	}

	public String rChooseFile( int arg1) {
		output.append("PdfChooseFile").append("\n");
		if (sysout) {
			System.out.println("PdfChooseFile");
		}

		return null;
	}

	public void rFlushConsole() {
		output.append("PdfFlushConsole").append("\n");

		if (sysout) {
			System.out.println("PdfFlushConsole");
		}

	}

	public void rLoadHistory(String arg1) {
		output.append("PdfLoadHistory").append("\n");
		if (sysout) {
			System.out.println("PdfLoadHistory");
		}

	}

	public String rReadConsole( String arg1, int arg2) {
		output.append("PdfReadConsole").append("\n");
		if (sysout) {
			System.out.println("PdfReadConsole");
		}

		return null;
	}

	public void rSaveHistory( String arg1) {
		output.append("PdfSaveHistory").append("\n");
		if (sysout) {
			System.out.println("PdfSaveHistory");
		}

	}

	public void rShowMessage( String arg1) {
		output.append("PdfShowMessage" + arg1).append("\n");
		if (sysout) {
			System.out.println("PdfShowMessage");
		}

	}

	public void rWriteConsole(String arg1, int arg2) {
		output.append(arg1).append("\n");
		if (sysout) {
			System.out.println(arg1);
		}

	}

	public void clearOutput() {
		output = new StringBuffer();
	}

	public String getOutput() {
		return output.toString();
	}
}
