package nz.govt.stats.pdi.pdfaddressmatcher;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import nz.govt.stats.pdi.pdfaddressmatcher.extensions.PRVariable;
import nz.govt.stats.pdi.pdfaddressmatcher.extensions.PdfRunner;

import org.eclipse.swt.widgets.Shell;
import org.pentaho.di.core.CheckResult;
import org.pentaho.di.core.CheckResultInterface;
import org.pentaho.di.core.Const;
import org.pentaho.di.core.Counter;
import org.pentaho.di.core.annotations.Step;
import org.pentaho.di.core.database.DatabaseMeta;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.exception.KettlePluginException;
import org.pentaho.di.core.exception.KettleStepException;
import org.pentaho.di.core.exception.KettleXMLException;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.core.row.ValueMetaInterface;
import org.pentaho.di.core.row.value.ValueMetaBase;
import org.pentaho.di.core.row.value.ValueMetaFactory;
import org.pentaho.di.core.variables.VariableSpace;
import org.pentaho.di.core.xml.XMLHandler;
import org.pentaho.di.repository.ObjectId;
import org.pentaho.di.repository.Repository;
import org.pentaho.di.shared.SharedObjectInterface;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.BaseStepMeta;
import org.pentaho.di.trans.step.StepDataInterface;
import org.pentaho.di.trans.step.StepDialogInterface;
import org.pentaho.di.trans.step.StepInterface;
import org.pentaho.di.trans.step.StepMeta;
import org.pentaho.di.trans.step.StepMetaInterface;
import org.pentaho.metastore.api.IMetaStore;
import org.w3c.dom.Node;

/**
 * This interface allows custom steps to talk to Kettle. The StepMetaInterface is the main Java 
 * interface that a plugin implements. The responsibilities of the implementing class are listed below:
 * - Provide instances of other plugin classes (dialog, data and step processing
 * - Serialising data for the configuration
 * - Reporting the input and output fields for the step (getFields)
 * - Validating settings
 * @author mdean
 *
 */
@Step(
		id = "PdfAddressMatcher",
		image = "/icon.png",
		i18nPackageName="nz.govt.stats.pdi.pdfaddressmatcher",
		name= "Matches and validate addresses",
		description = "xxxx",
		categoryDescription="i18n:org.pentaho.di.trans.step:BaseStep.Category.Lookup"
)
public class PdfAddressMatcherGetStepMeta extends BaseStepMeta implements StepMetaInterface {

    //private static Class<?> PKG = PdfAddressMatcherGetStepMeta.class; // for i18n purposes
		
	public Object[] arrFields; // Holds PDF Intech fileds
	public Object[] inputFieldsAndTypes; // Holds input data fields to sent to output
	private List<PRVariable> inputFields;
	private List<PRVariable> outputFields;
	private boolean inputTable;
	private boolean outputTable;
	private String grammar;
	private String version;
	private String pdfGrammar;
	PdfRunner pdf = new PdfRunner();
	
	// Common methods from PdfRunner class
	public String getPdfVersion(){		
		if (version == null | version==""){
			setPdfVersion();
		}
		return version;
	}
	public void setPdfVersion(){		
		version = pdf.getValueByTagNameFromPluginXml("Version");
	}
	
	public String getPdfGrammar(){		
		if (grammar == null | grammar == ""){
			setPdfGrammar();
		}
		return pdfGrammar;
	}
	public void setPdfGrammar(){		
		pdfGrammar = pdf.getValueByTagNameFromPluginXml("Grammar");
	}
	//*------------------
	
	
	  public String getGrammar() {
	        return grammar;
	    }

	    public void setGrammar(String where) {
	        this.grammar = where;
	    }
	
    public PdfAddressMatcherGetStepMeta() {
        super();
    }
    
    /**
	 * Load XML.
	 */
	public final void loadXML(final Node stepnode,
			final List<DatabaseMeta> databases,
			final Map<String, Counter> counters) throws KettleXMLException {
		readData(stepnode, databases);
	}

	/**
	 * Clone MetaData.
	 * 
	 * @return
	 */
	public final Object clone() {
		PdfAddressMatcherGetStepMeta retval = (PdfAddressMatcherGetStepMeta) super.clone();
		return retval;
	}

	/**
	 * Read meta data from XML.
	 * 
	 * @param stepnode
	 * @param databases
	 * @throws KettleXMLException
	 */
	private void readData(final Node stepnode,
			final List<? extends SharedObjectInterface> databases)
			throws KettleXMLException {
		try {
						
			grammar = XMLHandler.getTagValue(stepnode, "grammar");
			inputTable = false;
			String value = XMLHandler.getTagValue(stepnode, "inputTable");
			if (value != null && value.equals("true")) {
				inputTable = true;
			}
			this.inputFields = new ArrayList<PRVariable>();
			this.outputFields = new ArrayList<PRVariable>();

			Node infields = XMLHandler.getSubNode(stepnode, "inputfields");
			int nrInFields = XMLHandler.countNodes(infields, "inputfields");
			for (int i = 0; i < nrInFields; i++) {
				Node fnode = XMLHandler.getSubNodeByNr(infields, "inputfields", i);
				String rName = XMLHandler.getTagValue(fnode, "pdfname"); //I thought I will use this but  end up having only pentahoname, as getfield method handles input type for output
				String pentahoName = XMLHandler.getTagValue(fnode,
						"pentahoname");
				int type = Integer.parseInt(XMLHandler.getTagValue(fnode,
						"type")); //I thought I will use this but  end up having only pentahoname, as getfield method handles input type for output
				inputFields.add(new PRVariable(rName, pentahoName, type));
			}
			
			Node outfields = XMLHandler.getSubNode(stepnode, "outputfields");
			int nrOutFields = XMLHandler.countNodes(outfields, "outputfields");
			for (int i = 0; i < nrOutFields; i++) {
				Node fnode = XMLHandler.getSubNodeByNr(outfields, "outputfields",
						i);
				String rName = XMLHandler.getTagValue(fnode, "pdfname");
				String pentahoName = XMLHandler.getTagValue(fnode,
						"pentahoname");
				int type = Integer.parseInt(XMLHandler.getTagValue(fnode,
						"type"));
				outputFields.add(new PRVariable(rName, pentahoName, type));
			}
			
		} catch (Exception e) {
			throw new KettleXMLException("Unable to load step info from XML", e);
		}
	}

	/**
	 * Get XML for this step.
	 * 
	 * @return
	 */
	public final String getXML() {
		StringBuffer retval = new StringBuffer();
		
		retval.append("    ").append(
				XMLHandler.addTagValue("grammar", grammar));
		
		retval.append("    ").append(
				XMLHandler.addTagValue("inputTable", (inputTable ? "true"
						: "false")));
		retval.append("    <inputfields>").append(Const.CR);
		for (PRVariable field : inputFields) {
			retval.append("      <inputfields>").append(Const.CR);
			retval.append("        ").append(
					XMLHandler.addTagValue("rname", field.getpdfName()));
			retval.append("        ").append(
					XMLHandler.addTagValue("pentahoname",
							field.getPentahoName()));
			retval.append("        ").append(
					XMLHandler.addTagValue("type", field.getType()));
			retval.append("      </inputfields>").append(Const.CR);
		}
		retval.append("    </inputfields>").append(Const.CR);

		retval.append("    <outputfields>").append(Const.CR);
		for (PRVariable field : outputFields) {
			retval.append("      <outputfields>").append(Const.CR);
			retval.append("        ").append(
					XMLHandler.addTagValue("rname", field.getpdfName()));
			retval.append("        ").append(
					XMLHandler.addTagValue("pentahoname",
							field.getPentahoName()));
			retval.append("        ").append(
					XMLHandler.addTagValue("type", field.getType()));
			retval.append("      </outputfields>").append(Const.CR);
		}
		retval.append("    </outputfields>").append(Const.CR);
		
		return retval.toString();
	}

	/**
	 * Read step from repository.
	 * 
	 * @param rep
	 * @param idStep
	 * @param databases
	 * @param counters
	 * @throws KettleException
	 */
	public void readRep(Repository rep, ObjectId idStep,
			List<DatabaseMeta> databases, Map<String, Counter> counters)
			throws KettleException {
		try {
			
			this.grammar = rep.getStepAttributeString(idStep,
					"grammar");
			 
			inputTable = false;
			String value = rep.getStepAttributeString(idStep, "inputTable");
			if (value != null && value.equals("true")) {
				inputTable = true;
			}

			int nrInFields = rep
					.countNrStepAttributes(idStep, "inputfields_pdfname");
			for (int i = 0; i < nrInFields; i++) {
				String rName = rep.getStepAttributeString(idStep, i,
						"inputfields_pdfname");
				String pentahoName = rep.getStepAttributeString(idStep, i,
						"inputfields_pentahoname");
				int type = Integer.parseInt(rep.getStepAttributeString(idStep,
						i, "inputfields_type"));
				inputFields.add(new PRVariable(rName, pentahoName, type));
			}
			
			int nrOutFields = rep.countNrStepAttributes(idStep,
					"outputfields_pdfname");
			for (int i = 0; i < nrOutFields; i++) {
				String rName = rep.getStepAttributeString(idStep, i,
						"outputfields_pdfname");
				String pentahoName = rep.getStepAttributeString(idStep, i,
						"outputfields_pentahoname");
				int type = Integer.parseInt(rep.getStepAttributeString(idStep,
						i, "outputfields_type"));
				outputFields.add(new PRVariable(rName, pentahoName, type));
			}
			
		} catch (Exception e) {
			throw new KettleException(
					"Unexpected error reading step information from the repository",
					e);
		}
	}

	/**
	 * Save object to Repository.
	 * 
	 * @param rep
	 * @param idTransformation
	 * @param idStep
	 * @throws KettleException
	 */
	public void saveRep(Repository rep, ObjectId idTransformation,
			ObjectId idStep) throws KettleException {
		try {
			
			rep.saveStepAttribute(idTransformation, idStep, "grammar",
					grammar);
			
			rep.saveStepAttribute(idTransformation, idStep, "inputTable",
					(inputTable ? "true" : "false"));

			for (int i = 0; i < inputFields.size(); i++) {
				rep.saveStepAttribute(idTransformation, idStep, i,
						"inputfields_pdfname", inputFields.get(i).getpdfName());
				rep.saveStepAttribute(idTransformation, idStep, i,
						"inputfields_pentahoname", inputFields.get(i)
								.getPentahoName());
				rep.saveStepAttribute(idTransformation, idStep, i,
						"inputfields_type", inputFields.get(i).getType());
			}
			
			for (int i = 0; i < outputFields.size(); i++) {
				rep.saveStepAttribute(idTransformation, idStep, i,
						"outputfields_pdfname", outputFields.get(i).getpdfName());
				rep.saveStepAttribute(idTransformation, idStep, i,
						"outputfields_pentahoname", outputFields.get(i)
								.getPentahoName());
				rep.saveStepAttribute(idTransformation, idStep, i,
						"outputfields_type", outputFields.get(i).getType());
			}

		} catch (Exception e) {
			throw new KettleException(
					"Unable to save step information to the repository for idStep="
							+ idStep, e);
		}
	}

	/**
	 * Get fields for next step.
	 * 
	 * @param row
	 * @param origin
	 * @param info
	 * @param nextStep
	 * @param space
	 * @throws KettleStepException
	 */
	 @Override
	    public void getFields(
	            RowMetaInterface inputRowMeta,
	            String name,
	            RowMetaInterface[] info,
	            StepMeta nextStep,
	            VariableSpace space,
	            Repository repository,
	            IMetaStore metaStore
	    		) throws KettleStepException {

		 // Create value meta for specific input columns		 
		 // At first get fields name and types into the local array		 
		 if (inputFieldsAndTypes == null){
			 Object[] FieldNames = inputRowMeta.getFieldNames(); // name of the fields
			 Object[] Types =  inputRowMeta.getFieldNamesAndTypes(0); // holds types. This suppose to give types  with field name but seems at first time pentaho gives only types in the same order of fields 
			 // join field name and its type, for further processing 
			 for (int i = 0; i < FieldNames.length ; i++) {
				 FieldNames[i] = FieldNames[i].toString()+Types[i].toString();
			 }
			 inputFieldsAndTypes = FieldNames; // Field and types array to local array of meta class
		 }

		 inputRowMeta.clear();
		 // Check output fields/variables exits 
		 if(outputFields.size()>0){	
			 int FieldType = 2;
			 // Create meta data with correct incoming type. Find the fields and its types, then create meta data. 
			 for (int i = 0; i < outputFields.size(); i++) {
				 	Object[] ft1 = inputFieldsAndTypes; // Just to check inputFieldsAndTypes has elements or not, but then I continue with the local array. 
				 	for (int ft = 0; ft < ft1.length ; ft++){
				 		String FieldName = ft1[ft].toString().substring(0, ft1[ft].toString().indexOf("(")).trim(); // Get field name from previous step
				 		String sFieldName = outputFields.get(i).getPentahoName(); // Get field name from output dropdown box. User selected fileds for output
				 		if (FieldName.equals(sFieldName)){ // if equals then
				 			// Get type name, then check appropriate type and store pentaho type value into the Ftype.
				 			String TypeName = ft1[ft].toString().substring(ft1[ft].toString().indexOf("(")+ 1,ft1[ft].toString().indexOf(")")).trim(); 				 			
				 			switch (TypeName.toLowerCase()){
			        	    case "string":
			        	    	FieldType  = ValueMetaBase.TYPE_STRING;
			        	    	break;
			        	    case "integer":
			        	    	FieldType  = ValueMetaBase.TYPE_INTEGER;
			        	    	break;
			        	    case "date":
			        	    	FieldType  = ValueMetaBase.TYPE_DATE;
			        	    	break;
			        	    case "datetime":
			        	    	FieldType  = ValueMetaBase.TYPE_DATE;
			        	    	break;
			        	    case "float":
			        	    	FieldType  = ValueMetaBase.TYPE_NUMBER;
			        	    	break;
			        	    case "numeric":
			        	    	FieldType  = ValueMetaBase.TYPE_NUMBER;
			        	    	break;
			        	    case "number":
			        	    	FieldType  = ValueMetaBase.TYPE_NUMBER;
				        	    break;
			        	    case "bignumber":
			        	    	FieldType  = ValueMetaBase.TYPE_BIGNUMBER;
				        	    break;
			        	    case "decimal":
			        	    	FieldType  = ValueMetaBase.TYPE_BIGNUMBER;
				        	    break;
			        	    case "binary":
			        	    	FieldType  = ValueMetaBase.TYPE_BINARY;
				        	    break;
			        	    case "boolean":
			        	    	FieldType  = ValueMetaBase.TYPE_BOOLEAN;
			        	    	break;			        	    	
			        	    }								 			
				 		}
				 	}
				 	
					// Create meta for each columns with respective type.
				 	ValueMetaInterface v = new ValueMetaBase(outputFields.get(i).getPentahoName(),FieldType);
				 	//ValueMetaInterface v = new ValueMeta(outputFields.get(i).getPentahoName(),FieldType);
				 	try {
						v = ValueMetaFactory.createValueMeta(outputFields.get(i).getPentahoName(),FieldType);
					} catch (KettlePluginException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					v.setOrigin(name);
					inputRowMeta.addValueMeta(v);
				}
		 }
		 //-----------
		 
		 // Create value meta for pdf columns. Since PDF response back with string so all fields type will be string.
		 PdfRunner Pdf = new PdfRunner();
		 String batchStanFields = Pdf.getBatchStanFields(); 
		 this.arrFields =  batchStanFields.split("\\,", -1);
    	for (int j = 0; j < arrFields.length ; j++) {				
			ValueMetaInterface rid = new ValueMetaBase(arrFields[j].toString().trim(),ValueMetaBase.TYPE_STRING);
	    	rid.setTrimType(ValueMetaBase.TRIM_TYPE_BOTH);
	    	rid.setOrigin(name);
	    	inputRowMeta.addValueMeta(rid);
		}	    
	 }

	/**
	 * Check the step MetaData.
	 * 
	 * @param remarks
	 * @param transMeta
	 * @param stepMeta
	 * @param prev
	 * @param input
	 * @param output
	 * @param info
	 */
	public final void check(final List<CheckResultInterface> remarks,
			final TransMeta transMeta, final StepMeta stepMeta,
			final RowMetaInterface prev, final String input[],
			final String output[], final RowMetaInterface info) {
		CheckResult cr = new CheckResult(CheckResultInterface.TYPE_RESULT_OK,
				"OK", stepMeta);
		remarks.add(cr);
	}

	/**
	 * Get step.
	 * 
	 * @param stepMeta
	 * @param stepDataInterface
	 * @param cnr
	 * @param transMeta
	 * @param trans
	 * @return
	 */
	public final StepInterface getStep(final StepMeta stepMeta,
			final StepDataInterface stepDataInterface, final int cnr,
			final TransMeta transMeta, final Trans trans) {
		return new PdfAddressMatcherGetStep(stepMeta, stepDataInterface, cnr, transMeta, trans);
	}

	/**
	 * Get dialog.
	 * 
	 * @param shell
	 * @param meta
	 * @param transMeta
	 * @param name
	 * @return
	 */
	public StepDialogInterface getDialog(Shell shell, StepMetaInterface meta,
			TransMeta transMeta, String name) {
		return new PdfAddressMatcherGetStepDialog(shell, meta, transMeta, name);
	}

	/**
	 * Get step data.
	 * 
	 * @return
	 */
	public final StepDataInterface getStepData() {
		try {
			return new PdfAddressMatcherGetStepData();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Get used DB connections.
	 */
	public final DatabaseMeta[] getUsedDatabaseConnections() {
		return super.getUsedDatabaseConnections();
	}

	/**
	 * Set default values.
	 */
	@Override
	public void setDefault() {		
		inputFields= new ArrayList<PRVariable>();		
		//setGrammar("StatsNZ_NZAddressNPAD.grm"); //TODO: read from plugin.xml
		//PdfRunner Pdf = new PdfRunner();
		//setGrammar(Pdf.getValueByTagNameFromPluginXml("Grammar"));
		setGrammar(getPdfGrammar());
		
		outputFields = new ArrayList<PRVariable>();
	}

	/**
	 * Get script file path.
	 * 
	 * @return
	 */
	/*
	public String getRScript() {
		return rScript;
	}
	*/
	
	/**
	 * Get script file path.
	 * 
	 * @return
	 */
	
	/*
	public void setRScript(String rScript) {
		this.rScript = rScript;
	}
    */
	
	/**
	 * Get input vars.
	 * 
	 * @return
	 */
	public List<PRVariable> getInputFields() {
		return inputFields;
	}

	/**
	 * Set input vars.
	 * 
	 * @param inputVars
	 */
	public void setInputFields(List<PRVariable> inputFields) {
		this.inputFields = inputFields;
	}

	/**
	 * Get output vars.
	 * 
	 * @return
	 */
	
	public List<PRVariable> getOutputFields() {
		return outputFields;
	}
    
	
	/**
	 * Set output vars. 
	 *  Is this used to bind with dropdown box? or used for when user select from dropdown box so can be used into the getfields or any other class using getOutputVars?
	 * @param outputVars
	 */
	
	public void setOutputFields(List<PRVariable> outputFields) {
		this.outputFields = outputFields;
	}
    // tells dialog to show output table or not. calls from dialog class
	public boolean isOutputTable() {
		return outputTable;
	}
	public void setOutputTable(boolean outputTable) {
		this.outputTable = outputTable;
	}
	
	/**
	 * Set input vars.
	 * 
	 * @param outputVars
	 */
	public boolean isInputTable() {
		return inputTable;
	}

	public void setInputTable(boolean inputTable) {
		this.inputTable = inputTable;
	}
	
	
}
