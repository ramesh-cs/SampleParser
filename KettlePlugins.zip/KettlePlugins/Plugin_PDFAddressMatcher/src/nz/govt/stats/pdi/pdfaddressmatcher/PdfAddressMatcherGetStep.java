package nz.govt.stats.pdi.pdfaddressmatcher;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

//import org.pentaho.di.core.xml.XMLHandler;
import nz.govt.stats.pdi.pdfaddressmatcher.extensions.PRVariable;
import nz.govt.stats.pdi.pdfaddressmatcher.extensions.PdfRunner;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.row.RowDataUtil;
import org.pentaho.di.core.row.RowMeta;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.core.row.ValueMetaInterface;
import org.pentaho.di.core.xml.XMLHandler;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.BaseStep;
import org.pentaho.di.trans.step.StepDataInterface;
import org.pentaho.di.trans.step.StepInterface;
import org.pentaho.di.trans.step.StepMeta;
import org.pentaho.di.trans.step.StepMetaInterface;
/*
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
*/

/**
 * This class implements the row processing for the step. It initiates a connection to the response
 * api to read the specified survey.
 * @author mdean
 *
 */
public class PdfAddressMatcherGetStep extends BaseStep implements StepInterface {
 
	private int batchSize;
	private boolean GrammarErrorMessage = false;// Used as flag to show message onece only 
	private JsonRowReader rowReader;
    private PdfAddressMatcherGetStepMeta meta;
	private PdfAddressMatcherGetStepData data;
	private CloseableHttpClient closeableClient;
    /**
     * Default constructor
     * @param stepMeta a reference to this step's configuration
     * @param stepDataInterface defines the basic interface for the data used by a thread. This will allow us to stop execution of threads and restart them later on without loosing track of the situation. Typically the StepDataInterface implementing class will contain result sets, temporary data, caching indexes, etc.
     * @param copyNr if multiple copies of this instance of the step are running (i.e. multi-threaded) this is the thread number
     * @param transMeta
     * @param dis
     */
    public PdfAddressMatcherGetStep(
            StepMeta stepMeta,
            StepDataInterface stepDataInterface,
            int copyNr,
            TransMeta transMeta,
            Trans dis) {
        super(stepMeta, stepDataInterface, copyNr, transMeta, dis);
    }

    /**
	 * Run PDF and put result to output.
	 * 
	 * @param smi
	 * @param sdi
	 * @return
	 * @throws KettleException
	 */
	protected String runPDF(String ReqXml)
			throws Exception {
		PdfRunner Pdf = new PdfRunner();		
		String ResXml="";
		String url = Pdf.getUrl(); //"http://wdeviis15:4001/?wsdl";
		CloseableHttpClient httpClient = HttpSupport.OpenConnection(true); 
		
		  try {
	            HttpPost httpPost = new HttpPost(url.toString());
	            //Add your headers here
	            httpPost.setHeader( "SOAPAction", "BatchStan" );
	            
	            //Add xml to request body:	            
	            ContentType contentType = ContentType.create("text/xml", "UTF-8");
		    	HttpEntity requestBodyEntity = new StringEntity(ReqXml, contentType);
	    		httpPost.setEntity(requestBodyEntity);
	            
	            //logBasic("Executing request " + httpPost.getRequestLine());
	            CloseableHttpResponse response = httpClient.execute(httpPost);
	            //logBasic("Response " + response.getStatusLine());	            
	            
	            // TODO: handle failures here
	            if (response.getStatusLine().getStatusCode() == 200) {
	            	HttpEntity responseEntity = response.getEntity();
	            	
	            	StringBuilder sb = new StringBuilder();
	            	try {
	            	    BufferedReader reader = 
	            	           new BufferedReader(new InputStreamReader(responseEntity.getContent()), 65728);
	            	    String line = null;

	            	    while ((line = reader.readLine()) != null) {
	            	        sb.append(line);
	            	    }
	            	    ResXml = sb.toString();	            	     
	            	    //TODO do something with the output ("sb").
	            	}            	
	            	catch (Exception e) { 
	            		//throw new KettleException(e); 
	            	  	throw new KettleException("Error while Buffer reading response from PDF Intech Web Service. Status code: " 
	            				+ response.getStatusLine().getStatusCode() 
	            				+ ". Message: " 
	            				+ e.getMessage() 
	            				+ ". Reason Phrase: " 
	            				+response.getStatusLine().getReasonPhrase());
	            	}	            	
	            }
		  }
		  catch (Exception e){
			  logError("Unable to initialize the step" + " Version "+meta.getPdfVersion(), e);
			  logBasic(e.getMessage());
			  throw new KettleException("Unable to access PDF Intech web service" );
		  }
		  finally{
			  try {
				httpClient.close();
			} catch (IOException e) {
				//do nothing. Client must have already closed connection
				logError("Unable to close connection" + " Version "+meta.getPdfVersion(), e);
				  logBasic(e.getMessage());
				  throw new KettleException("Unable to access PDF Intech web service");
			}
		  }
		return ResXml;
	}
	
	
	
	
	/**
	 * Convert PDF Type to pentaho type.
	 * 
	 * @param rtype
	 * @return
	 */
	public static int convertRTypeToPentahoType(int rtype) {		
		return ValueMetaInterface.TYPE_STRING;
	}
	
	/**
	 * Process row. This method continuously called until rows finished. 
	 */
	public final boolean processRow(final StepMetaInterface smi,
			final StepDataInterface sdi) throws KettleException {
		// Get Input row
		Object[] rowInput = getRow();
		//String AddRow = "<ns2:item>" ;
		String AddRow = "" ;
		meta = (PdfAddressMatcherGetStepMeta) smi;
		data = (PdfAddressMatcherGetStepData) sdi;
		RowMetaInterface inputRowMeta = getInputRowMeta();
		try {		
			if (first) {
				// Get columns of Input source
				//ValueMetaInterface fullAdress = inputRowMeta.searchValueMeta("AddressFull");
				// Get all fields from the input
				//Fnames1 = getInputRowMeta().getFieldNames();				
				data.setFnames(getInputRowMeta().getFieldNames()); 
				 if (data.getFnames().length <0) //Fnames1.length<0 
				 { 
				   throw new KettleException("Can't find address field");
				 }
				 
				// Initialize selected lists of input and output fields/variables
				data.setInputFields(new PRVariable[meta.getInputFields().size()]);				
				data.setOutputFields(new PRVariable[meta.getOutputFields().size()]);
				
				// Meta for result output 
				RowMetaInterface outputRowMeta = new RowMeta();
		        meta.getFields(outputRowMeta, getStepname(), null, null, this, null, null); // Set meta info of input data into output and PDF Intech fields
		        data.setOutputRowMeta(outputRowMeta); // Store meta info to use in outputResultBatch() to create array structure for each row
				
				first = false;
			}
			
			if (rowInput == null) { // no more input to be expected... 							
				this.logDebug("No More Rows.");								
				if (data.getRowCount()>0){
					outputResultBatch();					
				}				
				setOutputDone();
				return false;
			}				
			
			// Look for specific variables (Columns) to read from the input source. If exists then only read specific variables (Columns) otherwise reads everything from the input source.
			if(data.getInputFields().length>0){
				for (int j = 0; j < data.getInputFields().length; j++) {					
					String Add = inputRowMeta.getString(rowInput, meta.getInputFields().get(j).getPentahoName(), meta.getInputFields().get(j).getPentahoName());
					AddRow = AddRow + Add + " ";
				}
			}
			else{ // This will read all fields from the source. If there are columns other than addresses then intech gives result output comes with the extra fields.  				
				for (int j = 0; j < data.getFnames().length ; j++) //Fnames1.length 
				{
					String Add = inputRowMeta.getString(rowInput, j);
					AddRow = AddRow + Add + " ";
				}				
			}			
			
			data.incrementRowCount();			
			//data.setsbAddXml(AddRow + "</ns2:item>"); // Make end tag for a row
			data.setsbAddXml( XMLHandler.addTagValue("ns2:item",AddRow)); // Make end tag for a row
			data.setRowsToWrite(Arrays.asList(rowInput)); // add rowInput into the array list. this will be used for input data into the output. this will be cleared after used.
						
			if (data.getRowCount()==batchSize){//batchSize
				outputResultBatch();
			}
															
			return true;
			
		} catch (Exception e) {
			throw new KettleException("Error calling address matcher"
					+ Arrays.toString(rowInput), e);
		}
		
		
	}
	
	protected void outputResultBatch() throws KettleException{
		try{
			
			// Prepare xml for request				
			String Grammar = meta.getGrammar();		
			if(Grammar==null || Grammar.isEmpty()){
				Grammar = meta.getPdfGrammar(); // Just in case use has emptied textbox and forgot to enter text file
				if (!GrammarErrorMessage){
					logBasic("PDF Service: Missing grammar file name. By default "+ Grammar + " has been taken. Please enter your grammar filename.");
					GrammarErrorMessage = true;
				}
				
			}
			XMLHandler.addTagValue("ns2:Grammar", Grammar);
			// TODO: replace String with xmlHalnder.
			String ReqXml ="<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns2=\"http://intechsolutions.com.au/soap2/\">"+
					"<SOAP-ENV:Body>" +
					"<ns2:BatchStan>" +
					//"<ns2:Grammar>" + Grammar +"</ns2:Grammar> <ns2:InputRecords>" +
					XMLHandler.addTagValue("ns2:Grammar", Grammar) + 
					"<ns2:InputRecords>"+
					data.getsbAddXml() +
					"</ns2:InputRecords>"+
					"<ns2:OutputDelimiter>|</ns2:OutputDelimiter>"+
					"</ns2:BatchStan>"+   
					"</SOAP-ENV:Body>"+
					"</SOAP-ENV:Envelope>";
			
			// Request to PDF Web Service and Response back. 
			String ResXml = runPDF(ReqXml); //Call PDF to match and validate
			// Get records string from response xml 
			String OutputRecords = ResXml.substring(ResXml.indexOf("<ns2:OutputRecords>"), ResXml.indexOf("</ns2:OutputRecords>")).replace("<ns2:OutputRecords>", "").replace("<ns2:item>", "");
			// Make record array
			Object[] ArrRecords = OutputRecords.split("</ns2:item>");
			// If any error then look for error return in response
			String ErrStr = "";
			ErrStr = ResXml.substring(ResXml.indexOf("<ns2:ErrorString>"), ResXml.indexOf("</ns2:ErrorString>"));
			ErrStr = ErrStr.replace("<ns2:ErrorString>", "");
			if (!ErrStr.isEmpty()) {								
				   throw new KettleException("Error from PDF Intech: " + ErrStr);
				 }
						
	        // Gets input row meta information
	        RowMetaInterface inputRowMeta = getInputRowMeta();
	        
	        Object[] inputFType= inputRowMeta.getFieldNamesAndTypes(0);
	        
	        for (int j = 0; j < ArrRecords.length; j++) {
	        	// Creates Each row array to print. Seen examples using resizeArray() takes two parameter, seems to me this method is to show output with inputdata but well suitable for row by row execution. However, here generating new dataset so this methods also works 
	        	Object[] out_row = RowDataUtil.allocateRowData(data.getOutputRowMeta().size()); // data.getOutputRowMeta().size() has meta defined in getFields() at first call. i.e. output structure
	        	// Get the batched input rows into the array
	        	List<Object> rowIn = (List<Object>) data.getRowsToWrite().get(j);				
				Object[] rowInput  =  rowIn.toArray();
				
	        	// Selected columns of Input data into the output result
	        	if (data.getOutputFields().length >0){
	        		for (int o = 0; o < data.getOutputFields().length; o++) {																			        				        			
	        			// Get Field/Column Index from Field names
	        			String FieldName = meta.getOutputFields().get(o).getPentahoName().trim();
	        			int FieldIndex = 0; 
	        			for (int f = 0; f < data.getFnames().length; f++) {
	        				if(data.getFnames()[f].equals(FieldName)){
	        					FieldIndex  = f;
	        				}
	        			}
	        			// Get type of the Field/Column
	        			String TypeName = inputFType[FieldIndex].toString().trim().replace("(", "").replace(")", "");
	        			// Get Field data into the out_row with respective type.
		        	    switch (TypeName.toLowerCase()){
		        	    case "string":		        	    	
		        	    	out_row[o] = inputRowMeta.getString(rowInput, meta.getOutputFields().get(o).getPentahoName(), meta.getOutputFields().get(0).getPentahoName());		        	    	
		        	    	break;
		        	    case "integer":		        	    	
		        	    	out_row[o] = inputRowMeta.getInteger(rowInput, FieldIndex);		        	    			        	    	
		        	    	break;
		        	    case "date":
		        	    	out_row[o] = inputRowMeta.getDate(rowInput, FieldIndex);
		        	    	break;
		        	    case "datetime":
		        	    	out_row[o] = inputRowMeta.getDate(rowInput, FieldIndex);
		        	    	break;
		        	    case "float":		        	    	
		        	    	out_row[o] = inputRowMeta.getBigNumber(rowInput, FieldIndex);
		        	    	break;
		        	    case "numeric":
		        	    	out_row[o] = inputRowMeta.getNumber(rowInput, FieldIndex);
		        	    	break;
		        	    case "number":
		        	    	out_row[o] = inputRowMeta.getNumber(rowInput, FieldIndex);
			        	    break;
		        	    case "bignumber":			        	    
			        	    out_row[o] = inputRowMeta.getBigNumber(rowInput, FieldIndex);
			        	    break;
		        	    case "decimal":			        	    
			        	    out_row[o] = inputRowMeta.getBigNumber(rowInput, FieldIndex);
			        	    break;
		        	    case "binary":
		        	    	out_row[o] = inputRowMeta.getBinary(rowInput, FieldIndex);
			        	    break;
		        	    case "boolean":
		        	    	out_row[o] = inputRowMeta.getBoolean(rowInput, FieldIndex);
		        	    	break;
		        	    }	        			
					}
	        	}	        	
	        	//------
	        	
	        	// PDF Result
	        	Object[] FieldValue  = ArrRecords[j].toString().split("\\|", -1); // Field value (data) array of each record					
				for (int i = 0; i < FieldValue.length; i++) {											
					if (data.getOutputFields().length >0){
						out_row[i + data.getOutputFields().length] = FieldValue[i].toString(); // Store PDF result after input data columns
					}else{						
						out_row[i] = FieldValue[i].toString(); // Stores only PDF Result
					}					
				}
				// Output the records
				putRow(data.getOutputRowMeta(),out_row); // Put output
				incrementLinesOutput();// For output, creates blank line of placeholder for next record
			}
	        data.clearCache(); // resets the variables.
		}catch (Exception e) {
			throw new KettleException("Error while processing request to and reponse from PDF Intech " + e.getMessage().toString());
		}
		
	} 
		
	private void If(boolean b) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Initialize step.
	 */
	public final boolean init(StepMetaInterface smi, StepDataInterface sdi) {
		meta = (PdfAddressMatcherGetStepMeta) smi;
		data = (PdfAddressMatcherGetStepData) sdi;
		PdfRunner Pdf = new PdfRunner();
		batchSize = Pdf.getBatchSize();
		logBasic("PDF Address Matcher Version "+meta.getPdfVersion());
		if (super.init(smi, sdi)) {
			try {
				// this.logDebug("Meta Fields: " + meta.getFields().size());
				return true;
			} catch (Exception e) {
				logError("An error occurred, processing will be stopped: "
						+ e.getMessage());
				setErrors(1);
				stopAll();
			}
		}
		return false;
	}
	
	/**
	 * Dispose step.
	 */
	public void dispose(StepMetaInterface smi, StepDataInterface sdi) {
		super.dispose(smi, sdi);
	}

} // End of class
