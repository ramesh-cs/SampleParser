package nz.govt.stats.pdi.pdfaddressmatcher;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import nz.govt.stats.pdi.pdfaddressmatcher.extensions.PRVariable;

import org.eclipse.swt.widgets.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.pentaho.di.core.Const;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.row.RowMeta;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.i18n.BaseMessages;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.BaseStepMeta;
import org.pentaho.di.trans.step.StepDialogInterface;
import org.pentaho.di.ui.core.widget.ColumnInfo;
import org.pentaho.di.ui.core.widget.TableView;
import org.pentaho.di.ui.trans.step.BaseStepDialog;

/**
 * The implementation of the configuration dialog for this step
 * @author Pratik
 *
 */
// this will allow the transformation to show the columns to subsequent steps.
public class PdfAddressMatcherGetStepDialog extends BaseStepDialog implements StepDialogInterface {

    private static Class<PdfAddressMatcherGetStepMeta> PKG = PdfAddressMatcherGetStepMeta.class; // for i18n purposes

    private Label wGrammarTip;
    
	private Text wGrammar;
	
	/**
	 * Input Table.
	 */
	private Button wInputTable;
	/**
	 * Input variables.
	 */
	private Label wlInputFields;

	/**
	 * Input variables.
	 */
	private TableView wInputFields;
	
	
	/**
	 * Out Table.
	 */
	private Button wOutputTable;
	/**
	 * Output variables.
	 */
	private TableView wOutputFields;

	/**
	 * Output variables.
	 */
	private Label wlOutputFields;
	
	/**
	 * Meta Data for Step.
	 */
	private PdfAddressMatcherGetStepMeta meta;
	
	/**
	 * Data for Step.
	 */
	private PdfAddressMatcherGetStepData data;

	/**
	 * All fields from the previous steps, used for dropdown selection.
	 */
	private RowMetaInterface prevFields = null;

	/**
	 * Field column.
	 */
	private ColumnInfo fieldColumnInputVars = null;
	private ColumnInfo fieldColumnOutputVars = null;
 
    
    
    public PdfAddressMatcherGetStepDialog(Shell parent, Object in, TransMeta transMeta, String sname) {
        super(parent, (BaseStepMeta) in, transMeta, sname);
        meta = (PdfAddressMatcherGetStepMeta) in;
    }

    /**
     * Create a label for a field
     * @param composite the dialog window
     * @param key the label text
     * @param formData the form to place the label in
     * @return
     */
    private Label createStandardLabel(Composite composite, String text, FormData formData) {
        Label label = new Label(composite, SWT.LEFT);
        label.setText(BaseMessages.getString(PKG, text, ""));
        props.setLook(label);
        label.setLayoutData(formData);
        return label;
    }
        
    /**
     * This method creates a text field entry without pentaho environment variable substitution.
     * @param composite the dialog window
     * @param initialValue the initial text to show in the text field
     * @param formData the form to place the label in
     * @param modifyListener
     * @return
     */
    private Text createStandardText(Composite composite, String initialValue, FormData formData, ModifyListener modifyListener) {
        Text result = new Text(composite, SWT.SINGLE | SWT.LEFT | SWT.BORDER);
        result.setText(initialValue);
        props.setLook(result);
        result.addModifyListener(modifyListener);
        result.setLayoutData(formData);
        return result;
    }
    private FormData createStandardLabelFormData(Control lastControl) {
        FormData ds = new FormData();
        ds.left = new FormAttachment(0, 0);
        ds.right = new FormAttachment(props.getMiddlePct(), -Const.MARGIN);

        if (null == lastControl) {
            ds.top = new FormAttachment(0, Const.MARGIN);
        } else {
            ds.top = new FormAttachment(lastControl, Const.MARGIN);
        }

        return ds;
    }

    private FormData createStandardControlFormData(Control lastControl) {
        FormData ds = new FormData();
        ds.left = new FormAttachment(props.getMiddlePct(), 0);
        ds.right = new FormAttachment(100, 0);

        if (null == lastControl) {
            ds.top = new FormAttachment(0, Const.MARGIN);
        } else {
            ds.top = new FormAttachment(lastControl, Const.MARGIN);
        }

        return ds;
    }
    /**
	 * Open dialog.
	 */
	@Override
	public String open() {		
		Shell parent = getParent();
		Display display = parent.getDisplay();

		shell = new Shell(parent, SWT.DIALOG_TRIM | SWT.RESIZE | SWT.MIN | SWT.MAX);
		//shell.setMinimumSize(750, 550);
		props.setLook(shell);
		setShellImage(shell, meta);

		ModifyListener lsMod = new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				meta.setChanged();
			}
		};
		backupChanged = meta.hasChanged();

		 
		FormLayout formLayout = new FormLayout();
		formLayout.marginWidth = Const.FORM_MARGIN;
		formLayout.marginHeight = Const.FORM_MARGIN;
		shell.setLayout(formLayout);
		shell.setText(BaseMessages.getString(PKG, "PRCalcDialog.Title", new String[0]) + " " + meta.getPdfVersion());
				//+ BaseMessages.getString(PKG, version, new String[0]));
		//int middle = props.getMiddlePct();
		int margin = Const.MARGIN;

		/*************************************************
		 * STEP NAME ENTRY
		 *************************************************/
		Control lastControl = null;
		{
            fdlStepname = createStandardLabelFormData(lastControl); // not sure why it keeps this?
            wlStepname = createStandardLabel(shell, "System.Label.StepName", fdlStepname); // Step name label
            wStepname = createStandardText(shell, stepname, createStandardControlFormData(lastControl), lsMod); // Step name text box
            lastControl = wStepname;
        }

        {
            createStandardLabel(shell, "PRCalcDialog.Grammar.Title", createStandardLabelFormData(lastControl)); // Grammar name label
            wGrammar = createStandardText(shell, "", createStandardControlFormData(lastControl), lsMod); // // Grammar name text box
            lastControl = wGrammar;
        }
        
        {
        	wGrammarTip = createStandardLabel(shell, "PRCalcDialog.Grammar.Tip", createStandardLabelFormData(lastControl)); // Grammar message             
            lastControl = wGrammarTip;
        }
					
		/*************************************************
		 * Properties group.
		 *************************************************/
		Group gProps = new Group(shell, SWT.SHADOW_ETCHED_IN);
		gProps.setText(BaseMessages.getString(PKG, "PRCalcDialog.Group", new String[0]));

		FormLayout gLayout = new FormLayout();
		gLayout.marginWidth = 5;
		gLayout.marginHeight = 5;
		gProps.setLayout(gLayout);
		props.setLook(gProps);

		FormData fdgProps = new FormData();
		fdgProps.top = new FormAttachment(wGrammarTip, margin);
		fdgProps.right = new FormAttachment(100, 0);
		fdgProps.left = new FormAttachment(0, 0);
		fdgProps.bottom = new FormAttachment(95, -margin);

		gProps.setLayoutData(fdgProps);

		/*************************************************
		 * Input is Table
		 *************************************************/
		
		wInputTable = new Button(gProps, SWT.CHECK);
		wInputTable.setText(BaseMessages.getString(PKG,
				"PRCalcDialog.InputTable", new String[0]));
		props.setLook(wInputTable);
		
		FormData fdlInputTable = new FormData();
		fdlInputTable.top = new FormAttachment(margin);
		fdlInputTable.left = new FormAttachment(0, margin);
		wInputTable.setLayoutData(fdlInputTable);
		

		wInputTable.setVisible(false);
		
		/*************************************************
		 * Input variables table
		 *************************************************/

		wlInputFields = new Label(gProps, SWT.NONE);
		wlInputFields.setText(BaseMessages.getString(PKG,
				"PRCalcDialog.InputVars", new String[0])); // Display label message above the input table 
		props.setLook(wlInputFields);
		FormData fdlInputVars = new FormData();
		fdlInputVars.left = new FormAttachment(0, 0);
		fdlInputVars.top = new FormAttachment(margin);
		wlInputFields.setLayoutData(fdlInputVars);

		int inputVarWidgetCols = 1;
		int inputVarWidgetRows = (meta.getInputFields() != null ? meta
				.getInputFields().size() : 1); // do not know what this does. perhaps put the place holder for row

		ColumnInfo[] ciInputVars = new ColumnInfo[inputVarWidgetCols];
		ciInputVars[0] = new ColumnInfo(BaseMessages.getString(PKG,
				"PRCalcDialog.InputVar.Column.PName", new String[0]),
				ColumnInfo.COLUMN_TYPE_CCOMBO, new String[] {}, false);	 //column label and column type 	
		fieldColumnInputVars = ciInputVars[0];

		wInputFields = new TableView(transMeta, gProps, SWT.BORDER
				| SWT.FULL_SELECTION | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL,
				ciInputVars, inputVarWidgetRows, lsMod, props);
		props.setLook(wInputFields); // This makes the table control with inside combo box with first row of place holder

		FormData fdInputVars = new FormData();
		fdInputVars.left = new FormAttachment(0, margin);
		fdInputVars.top = new FormAttachment(wlInputFields, margin);
		fdInputVars.right = new FormAttachment(100, -margin);
		fdInputVars.bottom = new FormAttachment(50, -margin);

		wInputFields.setLayoutData(fdInputVars); // place control on dialog window


		
		/*************************************************
		 * Output is Table
		 *************************************************/
		wOutputTable = new Button(gProps, SWT.CHECK);
		wOutputTable.setText(BaseMessages.getString(PKG,
				"PRCalcDialog.OutputTable", new String[0]));
		props.setLook(wOutputTable);
		
		FormData fdlOutputTable = new FormData();
		fdlOutputTable.top = new FormAttachment(wInputFields, margin);
		fdlOutputTable.left = new FormAttachment(0, margin);
		wOutputTable.setLayoutData(fdlOutputTable);
		

		wOutputTable.setVisible(false);
		
		/*************************************************
		 * Output Fields table
		 *************************************************/

		wlOutputFields = new Label(gProps, SWT.NONE);
		wlOutputFields.setText(BaseMessages.getString(PKG,
				"PRCalcDialog.OutputVars", new String[0]));
		props.setLook(wlOutputFields);
		FormData fdlOutputVars = new FormData();
		fdlOutputVars.left = new FormAttachment(0, margin);
		fdlOutputVars.top = new FormAttachment(wInputFields, margin);
		wlOutputFields.setLayoutData(fdlOutputVars);

		int outputVarWidgetCols = 1;
		int outputVarWidgetRows = (meta.getOutputFields() != null ? meta
				.getOutputFields().size() : 1);

		ColumnInfo[] ciOutputVars = new ColumnInfo[outputVarWidgetCols];
		ciOutputVars[0] = new ColumnInfo(BaseMessages.getString(PKG,
				"PRCalcDialog.OutputVar.Column.PName", new String[0]),
				ColumnInfo.COLUMN_TYPE_CCOMBO, new String[] {}, false);		
		fieldColumnOutputVars = ciOutputVars[0];

		wOutputFields = new TableView(transMeta, gProps, SWT.BORDER
				| SWT.FULL_SELECTION | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL,
				ciOutputVars, outputVarWidgetRows, lsMod, props);
		props.setLook(wOutputFields);

		FormData fdOutputVars = new FormData();
		fdOutputVars.left = new FormAttachment(0, margin);
		fdOutputVars.top = new FormAttachment(wlOutputFields, margin);
		fdOutputVars.right = new FormAttachment(100, -margin);
		fdOutputVars.bottom = new FormAttachment(100, -margin);

		wOutputFields.setLayoutData(fdOutputVars);

		/*************************************************
		 * // OK AND CANCEL BUTTONS
		 *************************************************/

		wOK = new Button(shell, SWT.PUSH);
		wOK.setText(BaseMessages.getString(PKG, "System.Button.OK", new String[0]));
		wCancel = new Button(shell, SWT.PUSH);
		wCancel.setText(BaseMessages.getString(PKG, "System.Button.Cancel", new String[0]));

		Button wHelp = new Button(shell, SWT.PUSH);
		wHelp.setText(BaseMessages.getString(PKG, "PRCalcDialog.Button.Help", new String[0]));

		BaseStepDialog.positionBottomButtons(shell, new Button[] { wOK,
				wCancel, wHelp }, margin, gProps);

		// Add listeners
		lsCancel = new Listener() {
			public void handleEvent(Event e) {
				cancel();
			}
		};
		lsOK = new Listener() {
			public void handleEvent(Event e) {
				ok();
			}
		};
		// Add listeners
		Listener lsHelp = new Listener() {
			public void handleEvent(Event e) {
				showHelp();
			}
		};

		wCancel.addListener(SWT.Selection, lsCancel);
		wOK.addListener(SWT.Selection, lsOK);
		wHelp.addListener(SWT.Selection, lsHelp);		

		/*************************************************
		 * // DEFAULT ACTION LISTENERS
		 *************************************************/

		lsDef = new SelectionAdapter() {
			public void widgetDefaultSelected(SelectionEvent e) {
				ok();
			}
		};

		wStepname.addSelectionListener(lsDef);
		// wRScriptToRun.addSelectionListener(lsDef);

		// Detect X or ALT-F4 or something that kills this window...
		shell.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent e) {
				cancel();
			}
		});

		// Set the shell size, based upon previous time...
		

		/*************************************************
		 * // POPULATE AND OPEN DIALOG
		 *************************************************/

		loadGuiFromModel();
		setPossibleInputFields();

		meta.setChanged(backupChanged);
		//BaseStepDialog.setSize(shell);
		setSize();
		shell.setSize(1000, 750);
		shell.setMinimumSize(750, 550);

		Rectangle shellBounds = shell.getBounds();
		Monitor monitor = shell.getDisplay().getPrimaryMonitor();
		if ( shell.getParent() != null){
			monitor = shell.getParent().getMonitor();
		}
		Rectangle monitorClientArea = monitor.getClientArea();
		
		int middleX = monitorClientArea.x + ( monitorClientArea.width - shellBounds.width)/2;
		int middleY = monitorClientArea.y + ( monitorClientArea.height - shellBounds.height)/2;
		shell.setLocation(middleX, middleY);
		
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}		
		return stepname;
	}

	/**
	 * Update notes in label. Show help.
	 */
	protected void showHelp() {
		String notes = "";
		
		notes = BaseMessages.getString(PKG, "PRCalcDialog.InstallNote.Step1", new String[0])
				+ "\n";
		
		notes += BaseMessages.getString(PKG, "PRCalcDialog.InstallNote.Step2", new String[0])
				+ "\n";
		
		notes += BaseMessages.getString(PKG, "PRCalcDialog.InstallNote.Step3", new String[0])
				+ "\n";

		MessageBox messageBox = new MessageBox(shell, SWT.ICON_INFORMATION
				| SWT.OK);
		messageBox.setText("Help");
		messageBox.setMessage(notes);
		messageBox.open();
	}

	/**
	 * Get type combo values.
	 * 
	 * @return
	 */
	protected static String[] getTypeComboValues() {
		String[] values = new String[] { "String", "Number", "Boolean" };
		return values;
	}

	/**
	 * Load GUI from model. I think populate value when dialog opens up.
	 */
	public void loadGuiFromModel() {
		wStepname.selectAll();
		if (meta.getGrammar() != null) {			
			wGrammar.setText(meta.getGrammar());
		}
		
		wInputTable.setSelection(meta.isInputTable());

		// Input variables
		if (meta.getInputFields() != null) {
			for (int i = 0; i < meta.getInputFields().size(); i++) {
				TableItem item = wInputFields.table.getItem(i);
				if (meta.getInputFields().get(i).getPentahoName() != null) {
					item.setText(1, meta.getInputFields().get(i).getPentahoName());
				}				
			}
		}
		wInputFields.setRowNums();
		wInputFields.optWidth(true);
		
		wOutputTable.setSelection(meta.isOutputTable());
		
		// Output variables
		if (meta.getOutputFields() != null) {
			for (int i = 0; i < meta.getOutputFields().size(); i++) {
				TableItem item = wOutputFields.table.getItem(i);
				if (meta.getOutputFields().get(i).getPentahoName() != null) {
					item.setText(1, meta.getOutputFields().get(i).getPentahoName());
				}				
			}
		}
		wOutputFields.setRowNums();
		wOutputFields.optWidth(true);

	}

	/**
	 * Set values for fields in ComboBox.
	 */
	private void setPossibleInputFields() {
		Runnable fieldLoader = new Runnable() {
			public void run() {
				try {
					prevFields = transMeta.getPrevStepFields(stepname);
				} catch (KettleException e) {
					prevFields = new RowMeta();
					String msg = BaseMessages.getString(PKG,
							"PRCalcDialog.Err.UnableToFindFields", new String[0]);
					logError(msg);
				}
				if (prevFields != null) {
					String[] prevStepFieldNames = prevFields.getFieldNames();
					Arrays.sort(prevStepFieldNames);
					fieldColumnInputVars.setComboValues(prevStepFieldNames);
					fieldColumnOutputVars.setComboValues(prevStepFieldNames);
				}
			}
		};
		new Thread(fieldLoader).start();
	}

	/**
	 * Variable type to number.
	 * 
	 * @param type
	 * @return
	 */
	protected String varTypeToStr(int type) {		
		return "String";
	}

	/**
	 * Variable type to string.
	 * 
	 * @param type
	 * @return
	 */
	protected int fieldTypeToString(String type) {

		return PRVariable.TYPE_STRING;
	}

	/**
	 * Cancel button action.
	 */
	private void cancel() {
		stepname = null;
		meta.setChanged(backupChanged);
		dispose();
	}

	/**
	 * OK button action.
	 */
	private void ok() {
		stepname = wStepname.getText();		
		meta.setGrammar(wGrammar.getText());
		meta.setInputTable(wInputTable.getSelection());
		meta.setOutputTable(wOutputTable.getSelection());
		// Input variables. (New) selected variables sets into the InputVars!
		int nrInputFields = wInputFields.nrNonEmpty();
		List<PRVariable> inputFields = new ArrayList<PRVariable>();
		PRVariable InField;
		for (int i = 0; i < nrInputFields; i++) {
			TableItem item = wInputFields.getNonEmpty(i);
			InField = new PRVariable(item.getText(2), item.getText(1),
					fieldTypeToString(item.getText(3)));
			inputFields.add(InField);
		}
		meta.setInputFields(inputFields);
		
		// output variables. (New) selected variables sets into the OutputVars!
		int nrOutputFields = wOutputFields.nrNonEmpty();
		List<PRVariable> outputFields = new ArrayList<PRVariable>();
		PRVariable OutField;
		for (int i = 0; i < nrOutputFields; i++) {
			TableItem item = wOutputFields.getNonEmpty(i);
			OutField = new PRVariable(item.getText(2), item.getText(1),
					fieldTypeToString(item.getText(3)));
			outputFields.add(OutField);
		}
		meta.setOutputFields(outputFields);

		dispose();
	}

}
