package nz.govt.stats.pdi.pdfaddressmatcher;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.WinHttpClients;
import org.pentaho.di.core.exception.KettleException;

public class HttpSupport {
	
	public static CloseableHttpClient OpenConnection(boolean useIntegratedSecurity) throws KettleException {
		CloseableHttpClient httpclient = null;
		
		if (useIntegratedSecurity) {        
        	// There is no need to provide user credentials
            // HttpClient will attempt to access current user security context through
            // Windows platform specific methods via JNI.
            if (!WinHttpClients.isWinAuthAvailable()) {
        		throw new KettleException("Integarted win auth is not supporteed");
        	}
        	
        	httpclient = WinHttpClients.createDefault();
        } else {
        	// Otherwise use some other type of authentication
        	httpclient = HttpClients.createDefault();
        	
        	//if (!username.isEmpty()) {
        		// TODO: implement basic or digest authentication or something
        		// httpclient.getState().setCredentials(
        		//	new AuthScope("host", 443, "realm"),
        		//  UsernamePasswordCredentials(username, password));
        	//}
        }
		
		return httpclient;
	}
	
}
