package nz.govt.stats.pdi.restclient;

import org.apache.http.entity.ContentType;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.trans.step.BaseStepData;
import org.pentaho.di.trans.step.StepDataInterface;

public class SNZRestClientPluginData extends BaseStepData implements StepDataInterface {

    public RowMetaInterface outputRowMeta;
    public RowMetaInterface inputRowMeta;

    /** URL **/
    public int indexOfUrlField;
    public String realUrl;
    /** Method **/
    public String method;
    /** Index of method **/
    public int indexOfMethod;

    public int nrheader;
    /** Headers **/
    public int[] indexOfHeaderFields;
    public String[] headerNames;

    /** query parameters **/
    public int nrParams;
    public int[] indexOfParamFields;
    public String[] paramNames;

    /** proxy **/
    public String realProxyHost;
    public int realProxyPort;
    public String realHttpLogin;
    public String realHttpPassword;

    /** Result fieldnames **/
    public String resultFieldName;
    public String resultCodeFieldName;
    public String resultResponseFieldName;
    public String resultHeaderFieldName;

    /** Flag set headers **/
    public boolean useHeaders;

    /** Flag set Query Parameters **/
    public boolean useParams;


    /** Flag set body **/
    public boolean useBody;

    /** Index of body field **/
    public int indexOfBodyField;

    public ContentType contentType;

    /** trust store **/
    public String trustStoreFile;
    public String trustStorePassword;

    public PoolingHttpClientConnectionManager httpConfig;


    public SNZRestClientPluginData()
    {
        super();
        this.indexOfUrlField = -1;

        this.realProxyHost = null;
        this.realProxyPort = 8080;
        this.realHttpLogin = null;
        this.realHttpPassword = null;
        this.resultFieldName = null;
        this.resultCodeFieldName = null;
        this.resultResponseFieldName = null;
        this.resultHeaderFieldName = null;
        this.nrheader = 0;
        this.nrParams = 0;
        this.method = null;
        this.indexOfBodyField = -1;
        this.indexOfMethod = -1;
        this.httpConfig = null;
        this.trustStoreFile = null;
        this.trustStorePassword = null;
    }
}
