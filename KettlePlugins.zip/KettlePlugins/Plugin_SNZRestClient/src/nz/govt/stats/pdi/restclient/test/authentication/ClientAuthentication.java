package nz.govt.stats.pdi.restclient.test.authentication;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.RequestLine;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.HashMap;

public class
ClientAuthentication {

    public HashMap<String, String> athenticate() throws IOException {

        HashMap<String, String> map = new HashMap();

        CloseableHttpClient httpclient;
        if (!WinHttpClients.isWinAuthAvailable()) {

            httpclient = WinHttpClients.createDefault();
            map.put("isWinAuthPossible", "true");

        }else{

            httpclient = HttpClients.createDefault();
            map.put("isWinAuthPossible", "false");
        }

//        String url = "http://localhost:56643/api/values";
        String url = "http://localhost:47503/index.html";
//        HttpHost target = new HttpHost(url);
//        HttpClientContext context = HttpClientContext.create();

        // There is no need to provide user credentials
        // HttpClient will attempt to access current user security context through
        // Windows platform specific methods via JNI.
        try {
            HttpGet httpget = new HttpGet(url);

            RequestLine reqStatus = httpget.getRequestLine();

//            System.out.println("Executing request " + httpget.getRequestLine());
            CloseableHttpResponse response = httpclient.execute(httpget);
            map.put("successfullyExecuted", "true " +  response.toString());
//            CloseableHttpResponse response = httpclient.execute(httpget);
//            try {

                StatusLine status = response.getStatusLine();
                map.put("Status code: ", status.getReasonPhrase() +  status.getStatusCode());
//                EntityUtils.consume(response.getEntity());
//            }catch (IOException e) {
//                e.printStackTrace();
//            } finally {
//                response.close();
//            }


        }catch (IOException e) {
            e.printStackTrace();
        } finally {
            httpclient.close();
        }

        return map;
    }
}
