package nz.govt.stats.pdi.restclient.test;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;

public class mainclass {

    public static void main(String[] args){


//        Properties props = new Properties();
//
//        try {
//            System.in.snz();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        System.out.println ("Trying to snz prop file ");
//        try {
//            props.load(ClassLoader.getSystemResourceAsStream("./parameters.properties"));
//            System.out.println(props.getProperty("Read.Store.URL"));
//
//        }catch (IOException e) {
//            e.printStackTrace();
//        }


//        URL path = mainclass.class.getProtectionDomain().getCodeSource().getLocation();

        List<File> listOfFiles1 = Collections.EMPTY_LIST;
        List<File> listOfFiles2 = Collections.EMPTY_LIST;

        File file1 = new File("C:\\Users\\rsivaram\\Desktop\\Tests\\testingJava\\lib");
        File file2 = new File("C:\\Users\\rsivaram\\Desktop\\Pentaho\\KettlePlugins\\lib");

        List<String> listNamesFromFile1 = new ArrayList();
        List<String> listNamesFromFile2 = new ArrayList();

        if (file1 != null){

            listOfFiles1 = Arrays.asList(file1.listFiles());

        }
        if (listOfFiles1 != null && !listOfFiles1.isEmpty()){

            for (File singleFile : listOfFiles1) {
                String fileName = singleFile.getName();
//                System.out.println(singleFile.getName());
                int dot = fileName.indexOf(".");
                String name = fileName.substring(0, dot-1);
                String correctedName = "";
                if(name.endsWith("-"))
                {
                    name  = name.substring(0, name.length() - 1);
                    listNamesFromFile1.add(name);
                }else {
                }
//                String revision = fileName.substring(dot-1, fileName.lastIndexOf("."));
//                System.out.println("<dependency org=\"general\" name=" + name +" rev=" + revision + " conf=\"pentahocore->default\"/>");

            }
        }

        if (file2 != null){

            listOfFiles2 = Arrays.asList(file2.listFiles());
        }

        if (listOfFiles2 != null && !listOfFiles2.isEmpty()){

            for (File singleFile : listOfFiles2) {
                String fileName = singleFile.getName();
//                System.out.println(singleFile.getName());
                int dot = fileName.indexOf(".");
                String name = fileName.substring(0, dot-1);
                String correctedName = "";
                if(name.endsWith("-"))
                {
                    name  = name.substring(0, name.length() - 1);
                    listNamesFromFile2.add(name);
                }
//                String revision = fileName.substring(dot-1, fileName.lastIndexOf("."));
//                System.out.println("<dependency org=\"general\" name=" + name +" rev=" + revision + " conf=\"pentahocore->default\"/>");

            }
        }

        int count = 0;
        for (String nameToMatch : listNamesFromFile1) {
            boolean foundMatch = false;
            count++;
            for (String nameToMatchFrom2 : listNamesFromFile2) {

                if (nameToMatch.equalsIgnoreCase(nameToMatchFrom2)){
                    foundMatch = true;
                }
            }
            if (!foundMatch){
                System.out.println("Unable to find match for " + nameToMatch);
            }else {
                System.out.println(count + ". Found match for " + nameToMatch);
            }
        }


//
//        try {
//            File file = new File(path.toURI());
//
//            File parentFolder = getDirectory(new File(file.getParent()));
//
//            if (parentFolder != null){
//
//                listOfFiles = Arrays.asList(parentFolder.listFiles());
//            }
//        } catch (URISyntaxException e) {
//            e.printStackTrace();
//        }
//
//        if (listOfFiles != null && !listOfFiles.isEmpty()){
//
//            for (File singleFile : listOfFiles) {
//                if (!singleFile.isFile() && singleFile.getName().equalsIgnoreCase("conf")) {
//
//                    System.out.println("SNZRestClientPlugin: Found config file" );
//                    loadProperties(singleFile);
//                }
//            }
//        }

        try {
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static File getDirectory(File file){

        if(!file.isDirectory()){
            return getDirectory(new File(file.getParent()));
        }
        return file;
    }

    private static void loadProperties(File config){

        List<File> configs = Arrays.asList(config.listFiles());
        System.out.println("SNZRestClientPlugin: reached loadProperties, number of files in config - " + configs.size());
        System.out.println(" SNZRestClientPlugin: Path: " + config.getAbsolutePath());
        if (configs.size() > 0)
        {
            File propsFile  = configs.get(0);
            System.out.println(" SNZRestClientPlugin: config file abs path" + propsFile.getAbsolutePath());

            InputStream propsStream = null;
            try {
                propsStream = new FileInputStream(propsFile);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            Properties props = new Properties();
            try {
                props.load(propsStream);
            } catch (IOException e) {
                e.printStackTrace();
            }

            String url = props.getProperty("Read.Store.URL");
            System.out.println(url);
        }
    }

}
