package nz.govt.stats.pdi.restclient;

import org.apache.http.*;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.config.ConnectionConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.WinHttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONObject;
import org.pentaho.di.core.Const;
import org.pentaho.di.core.encryption.Encr;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.exception.KettleValueException;
import org.pentaho.di.core.row.RowDataUtil;
import org.pentaho.di.i18n.BaseMessages;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.BaseStep;
import org.pentaho.di.trans.step.StepDataInterface;
import org.pentaho.di.trans.step.StepInterface;
import org.pentaho.di.trans.step.StepMeta;
import org.pentaho.di.trans.step.StepMetaInterface;
import org.pentaho.di.trans.steps.rest.RestMeta;
import javax.net.ssl.SSLContext;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.*;


public class SNZRestClientPlugin extends BaseStep  implements StepInterface {

    private static Class<?> PKG = SNZRestClientPluginMeta.class; //Internationalisation - to read relevant property files

    private SNZRestClientPluginMeta meta;
    private SNZRestClientPluginData data;

    public SNZRestClientPlugin(StepMeta s, StepDataInterface stepDataInterface, int c, TransMeta t, Trans dis) {
        super(s, stepDataInterface, c, t, dis);
    }


    private Object[]  executeRestCall( Object[] rowData ) throws KettleException {

        // used for calculating the responseTime
        long startTime = System.currentTimeMillis();

        Object[] newRow = null;
        if ( rowData != null ) {
            newRow = rowData.clone();
        }

        if ( meta.isUrlInField() ) {
            data.realUrl = data.inputRowMeta.getString( rowData, data.indexOfUrlField );
        }

        // get dynamic method?
        if ( meta.isDynamicMethod() ) {
            data.method = data.inputRowMeta.getString( rowData, data.indexOfMethod );
            if ( Utils.isEmpty( data.method ) ) {
                throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Error.MethodMissing" ) );
            }
        }

        //todo: Not sure if this is required !!!
        if ( isDetailed() ) {
            logDetailed( BaseMessages.getString( PKG, "SNZ.RestClient.Log.ConnectingToURL", data.realUrl ) );
        }

        CloseableHttpClient httpclient;

        if(!meta.isWindowsAuthentication()){

            httpclient = basicAuthentication();
            logDetailed( BaseMessages.getString( PKG, "SNZ.RestClient.Log.ConnectUsingNonWinAuth", data.realUrl ) );

        }else if(meta.isWindowsAuthentication() && !WinHttpClients.isWinAuthAvailable()){

                throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Error.WinAuthNotPossible") );
        }else{

            httpclient = WinHttpClients.custom()
//                    .setSSLSocketFactory(setUpSSLComms())
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .build();
        }

        HttpRequestBase httpResquest = null;

        switch (data.method){
            case RestMeta.HTTP_METHOD_GET: httpResquest = constructGet(rowData);
                break;
            case RestMeta.HTTP_METHOD_POST: httpResquest = constructPost(rowData);
                break;
            default: httpResquest = new HttpGet(data.realUrl);
        }

        //Todo: code needs to be implemented for supporting proxy authentication.
        String proxyHost = data.realProxyHost;
        int proxyPort = data.realProxyPort;

        CloseableHttpResponse response = null;

        Header[] reqHeaders = getRequestHeaders(rowData);
        if (reqHeaders.length > 0){
            httpResquest.setHeaders(reqHeaders);
        }

        try {
            response = httpclient.execute(httpResquest);
        }catch (IOException e) {
            logBasic("SNZRestClientPlugin: " + e.getLocalizedMessage());
            e.printStackTrace();
        }

        // Get response time
        long responseTime = System.currentTimeMillis() - startTime;
        if ( isDetailed() ) {
            logDetailed( BaseMessages
                    .getString( PKG, "SNZ.RestClient.Log.ResponseTime", String.valueOf( responseTime ), data.realUrl ) );
        }

        String body = handleResponse(response);

        // get Header
        Header[] headers = response.getAllHeaders();
        JSONObject json = new JSONObject();
        for ( Header entry : headers ) {
            String name = entry.getName();
            String value = entry.getValue();
            json.put( name, value );
        }
        String headerString = json.toJSONString();
        // for output
        int returnFieldsOffset = data.inputRowMeta.size();
        // add response to output
        if ( !Utils.isEmpty( data.resultFieldName ) ) {
            newRow = RowDataUtil.addValueData( newRow, returnFieldsOffset, body );
            returnFieldsOffset++;
        }

        // add status to output
        if ( !Utils.isEmpty( data.resultCodeFieldName ) ) {
            newRow = RowDataUtil.addValueData( newRow, returnFieldsOffset, new Long( response.getStatusLine().getStatusCode()) );
            returnFieldsOffset++;
        }

        // add response header to output
        if ( !Utils.isEmpty( data.resultHeaderFieldName ) ) {
            newRow = RowDataUtil.addValueData( newRow, returnFieldsOffset, headerString.toString() );
        }

        // add response time to output
        if ( !Utils.isEmpty( data.resultResponseFieldName ) ) {
            newRow = RowDataUtil.addValueData( newRow, returnFieldsOffset, new Long( responseTime ) );
        }

        try {
            httpclient.close();

        } catch (IOException e) {
            throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Error.ClosingHTTPClient", e));
        }

        return newRow;
    }

    private CloseableHttpClient basicAuthentication() {

        String login = data.realHttpLogin;
        String password = data.realHttpPassword;

        if ( Utils.isEmpty( login ) || Utils.isEmpty( password )) {
            logDetailed( BaseMessages.getString( PKG, "SNZ.RestClient.Warning.Credentials"));
            return HttpClients
                    .custom()
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .build();
        }

        CloseableHttpClient httpclient;

        if ( !Utils.isEmpty(data.realHttpLogin) ){

            BasicCredentialsProvider credsProvider = new BasicCredentialsProvider();

            credsProvider.setCredentials( AuthScope.ANY, new UsernamePasswordCredentials(login, password));

            httpclient = HttpClients.custom()
//                    .setSSLSocketFactory(setUpSSLComms())
                    .setDefaultCredentialsProvider(credsProvider)
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .build();
        }else {

            httpclient = HttpClients.custom()
//                    .setSSLSocketFactory(setUpSSLComms())
                        .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .build();
        }

        return httpclient;
    }

    private HttpPost constructPost(Object[] rowData){

        HttpPost httpPost = new HttpPost(data.realUrl);
        StringEntity body = getRequestBody(rowData);
        List<NameValuePair> nameValuePairs = getRequestParameters(rowData);
        try {
            httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            httpPost.setEntity(body);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return httpPost;
    }

    private HttpGet constructGet(Object[] rowData){

        HttpGet httpGet = new HttpGet(data.realUrl);
        return httpGet;
    }

    private StringEntity getRequestBody(Object[] rowData){

        StringEntity entity = null;
        if ( data.useBody ) {
            // Set Http request entity
            String entityString = null;
            try {
                entityString = Utils.NVL( data.inputRowMeta.getString( rowData, data.indexOfBodyField ), "" );
            } catch (KettleValueException e) {
                e.printStackTrace();
            }
            entity = new StringEntity(entityString, Charset.defaultCharset());
        }
        return entity;
    }

    private List<NameValuePair> getRequestParameters(Object[] rowData){

        List<NameValuePair> nameValuePairs = new ArrayList<>(data.nrParams);
        if ( data.useParams ) {

            for ( int i = 0; i < data.nrParams; i++ ) {

                String value = "";
                try {
                    value = data.inputRowMeta.getString( rowData, data.indexOfParamFields[i] );
                } catch (KettleValueException e) {
                    e.printStackTrace();
                }
                nameValuePairs.add(new BasicNameValuePair(data.paramNames[i], value));
            }
        }

        return nameValuePairs;
    }

    private Header[] getRequestHeaders(Object[] rowData){

        Header[] headers = new Header[data.nrheader + 1];
        String value = "";
        headers[0] = new BasicHeader(HttpHeaders.CONTENT_TYPE, data.contentType.getMimeType());

        if ( data.useHeaders ) {
            for ( int i = 0; i < data.nrheader; i++ ) {
                try {
                    value = data.inputRowMeta.getString( rowData, data.indexOfHeaderFields[i] );
                } catch (KettleValueException e) {
                    e.printStackTrace();
                }
                Header newhead = new BasicHeader(data.headerNames[i], value);
                headers[i+1] = newhead;
            }
        }
        return headers;
    }

    /**
     * Used for secure communication - setting up an ssl context using provided trust file and credentials
     */
    private SSLConnectionSocketFactory setUpSSLComms(){
        // Trust own CA and all self-signed certs

        SSLContext sslcontext = null;
        try {
            if (!Utils.isEmpty( data.trustStorePassword )){
                sslcontext = SSLContexts.custom()
                        .loadTrustMaterial(new File(data.trustStoreFile), data.trustStorePassword.toCharArray(),
                                new TrustSelfSignedStrategy())
                        .build();
            }else {

                sslcontext = SSLContexts.custom()
                        .loadTrustMaterial(new File(data.trustStoreFile))
                        .build();
            }

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (sslcontext == null){
            logDetailed( BaseMessages.getString( PKG, "SNZ.RestClient.Exception.EmptySSLContext"));
        }
        // Allow TLSv1 protocol only
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
                sslcontext,
                new String[] { "TLSv1" },
                null,
                SSLConnectionSocketFactory.getDefaultHostnameVerifier());
        return sslsf;
    }

    private String handleResponse(CloseableHttpResponse response) throws KettleException {

        String responseBody = null;

        if (response != null){

            int status = response.getStatusLine().getStatusCode();
            logDebug( BaseMessages.getString( PKG, "SNZ.RestClient.Log.ResponseCode", "" + status ) );
            HttpEntity entity = response.getEntity();
            try {
                responseBody  = entity != null ? EntityUtils.toString(entity) : "";
            } catch (ParseException ex) {
                throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Error.ResponseEntity"), ex);
            } catch (IOException e) {
                throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Error.ResponseEntity"), e);
            }
            if (status >= 200 && status < 300) {

                return responseBody;

            } else {
                throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Error.Connection.RequestFailure", status,response.getStatusLine().getReasonPhrase() + "; " + BaseMessages.getString( PKG, "SNZ.RestClient.Error.Connection.ServerMessage", responseBody)));
            }
        }

        return responseBody;
    }

    private void setConfig() throws KettleException {

        /**
         * This config can be further developed to accept more parameters
         */
        if (data.httpConfig == null){
            // Create global request configuration
            data.httpConfig = new PoolingHttpClientConnectionManager();
            data.httpConfig.setValidateAfterInactivity(10000);

            RequestConfig defaultRequestConfig = RequestConfig.custom()
                    .setCookieSpec(CookieSpecs.DEFAULT)
                    .setExpectContinueEnabled(true)
                    .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.DIGEST))
                    .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.BASIC))
                    .build();

            ConnectionConfig connectionConfig = ConnectionConfig.custom()
                    .setMalformedInputAction(CodingErrorAction.REPORT)
                    .setCharset(StandardCharsets.UTF_8)
                    .build();
            data.httpConfig.setDefaultConnectionConfig(connectionConfig);
        }
    }

    public boolean processRow( StepMetaInterface smi, StepDataInterface sdi ) throws KettleException {
        meta = (SNZRestClientPluginMeta) smi;
        data = (SNZRestClientPluginData) sdi;

        Object[] r = getRow(); // Get row from input rowset & set row busy!

        if ( r == null ) {
            // no more input to be expected...
            setOutputDone();
            return false;
        }

        if ( first ) {
            first = false;

            data.inputRowMeta = getInputRowMeta();
            data.outputRowMeta = data.inputRowMeta.clone();
            meta.getFields( data.outputRowMeta, getStepname(), null, null, this, repository, metaStore );

            // Let's set URL
            if ( meta.isUrlInField() ) {
                if ( Utils.isEmpty( meta.getUrlField() ) ) {
                    logError( BaseMessages.getString( PKG, "SNZ.RestClient.Log.NoField") );
                    throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Log.NoField") );
                }

                // cache the position of the field
                if ( data.indexOfUrlField < 0 ) {
                    String realUrlfieldName = environmentSubstitute( meta.getUrlField() );
                    data.indexOfUrlField = data.inputRowMeta.indexOfValue( realUrlfieldName );
                    if ( data.indexOfUrlField < 0 ) {
                        // The field is unreachable !
                        throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Exception.ErrorFindingField",
                                realUrlfieldName ) );
                    }
                }
            } else {
                // Static URL
                data.realUrl = environmentSubstitute( meta.getUrl() );
            }

            // Check Method
            if ( meta.isDynamicMethod() ) {
                String field = environmentSubstitute( meta.getMethodFieldName() );
                if ( Utils.isEmpty( field ) ) {
                    throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Exception.MethodFieldMissing") );
                }
                data.indexOfMethod = data.inputRowMeta.indexOfValue( field );
                if ( data.indexOfMethod < 0 ) {
                    // The field is unreachable !
                    throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Exception.ErrorFindingField", field ) );
                }
            }

            // set Headers
            int numberOfHeaderArgs = meta.getHeaderName() == null ? 0 : meta.getHeaderName().length;
            if ( numberOfHeaderArgs > 0 ) {
                data.nrheader = numberOfHeaderArgs;
                data.indexOfHeaderFields = new int[numberOfHeaderArgs];
                data.headerNames = new String[numberOfHeaderArgs];
                for ( int i = 0; i < numberOfHeaderArgs; i++ ) {
                    // split into body / header
                    data.headerNames[i] = environmentSubstitute( meta.getHeaderName()[i] );
                    String field = environmentSubstitute( meta.getHeaderField()[i] );

                    if ( Utils.isEmpty( field ) ) {
                        throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Exception.HeaderFieldEmpty") );
                    }
                    data.indexOfHeaderFields[i] = data.inputRowMeta.indexOfValue( field );
                    if ( data.indexOfHeaderFields[i] < 0 ) {
                        throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Exception.ErrorFindingField", field ) );
                    }
                }

                data.useHeaders = true;
            }

            // get parameters
            if ( RestMeta.isActiveParameters( meta.getMethod() ) ) {
                int numberOfparams = meta.getParameterField() == null ? 0 : meta.getParameterField().length;
                if ( numberOfparams > 0 ) {
                    data.nrParams = numberOfparams;
                    data.paramNames = new String[numberOfparams];
                    data.indexOfParamFields = new int[numberOfparams];
                    for ( int i = 0; i < numberOfparams; i++ ) {
                        data.paramNames[i] = environmentSubstitute( meta.getParameterName()[i] );
                        String field = environmentSubstitute( meta.getParameterField()[i] );
                        if ( Utils.isEmpty( field ) ) {
                            throw new KettleException( BaseMessages.getString( PKG, "Rest.Exception.ParamFieldEmpty" ) );
                        }
                        data.indexOfParamFields[i] = data.inputRowMeta.indexOfValue( field );
                        if ( data.indexOfParamFields[i] < 0 ) {
                            throw new KettleException( BaseMessages.getString( PKG, "Rest.Exception.ErrorFindingField", field ) );
                        }
                    }
                    data.useParams = true;
                }
            }

            if ( SNZRestClientPluginMeta.isActiveBody( meta.getMethod() ) ) {
                String field = environmentSubstitute( meta.getBodyField() );
                if ( !Utils.isEmpty( field ) ) {
                    data.indexOfBodyField = data.inputRowMeta.indexOfValue( field );
                    if ( data.indexOfBodyField < 0 ) {
                        throw new KettleException( BaseMessages.getString( PKG, "SNZ.RestClient.Exception.ErrorFindingField", field ) );
                    }
                    data.useBody = true;
                }
            }
        }

        try {

            Object[] outputRowData = executeRestCall( r );

            putRow( data.outputRowMeta, outputRowData ); // copy row to output rowset(s);

            if ( checkFeedback( getLinesRead() ) ) {
                if ( isDetailed() ) {
                    logDetailed( BaseMessages.getString( PKG, "SNZ.RestClient.LineNumber") + getLinesRead() );
                }
            }
        } catch ( KettleException e ) {
            boolean sendToErrorRow = false;
            String errorMessage = null;

            if ( getStepMeta().isDoingErrorHandling() ) {
                sendToErrorRow = true;
                errorMessage = e.toString();
            } else {
                logError( BaseMessages.getString( PKG, "SNZ.RestClient.ErrorInStepRunning") + e.getMessage() );
                setErrors( 1 );
                logError( Const.getStackTracker( e ) );
                stopAll();
                setOutputDone(); // signal end to receiver(s)
                return false;
            }

            if ( sendToErrorRow ) {
                // Simply add this row to the error row
                putError( getInputRowMeta(), r, 1, errorMessage, null, "Rest001" );
            }

        }

        return true;
    }

    public boolean init( StepMetaInterface smi, StepDataInterface sdi ) {
        meta = (SNZRestClientPluginMeta) smi;
        data = (SNZRestClientPluginData) sdi;

        String applicationType = Utils.NVL( meta.getApplicationType(), "" );

        if (applicationType.equals(SNZRestClientPluginMeta.APPLICATION_TYPE_JSON)){

            data.contentType = ContentType.APPLICATION_JSON;

        }else if (applicationType.equals(SNZRestClientPluginMeta.APPLICATION_TYPE_XML)){

            data.contentType = ContentType.APPLICATION_XML;
        }

        if ( super.init( smi, sdi ) ) {

            data.resultFieldName = environmentSubstitute( meta.getFieldName() );
            data.resultCodeFieldName = environmentSubstitute( meta.getResultCodeFieldName() );
            data.resultResponseFieldName = environmentSubstitute( meta.getResponseTimeFieldName() );
            data.resultHeaderFieldName = environmentSubstitute( meta.getResponseHeaderFieldName() );

            // get authentication settings once
            data.realProxyHost = environmentSubstitute( meta.getProxyHost() );
            data.realProxyPort = Const.toInt( environmentSubstitute( meta.getProxyPort() ), 8080 );
            data.realHttpLogin = environmentSubstitute( meta.getHttpLogin() );
            data.realHttpPassword =
                    Encr.decryptPasswordOptionallyEncrypted( environmentSubstitute( meta.getHttpPassword() ) );

            if ( !meta.isDynamicMethod() ) {
                data.method = environmentSubstitute( meta.getMethod() );
                if ( Utils.isEmpty( data.method ) ) {
                    logError( BaseMessages.getString( PKG, "SNZ.RestClient.Error.MethodMissing") );
                    return false;
                }
            }

            data.trustStoreFile = environmentSubstitute( meta.getTrustStoreFile() );
            data.trustStorePassword = environmentSubstitute( meta.getTrustStorePassword() );

            try {
                setConfig();
            } catch ( Exception e ) {
                logError( BaseMessages.getString( PKG, "SNZ.RestClient.Error.Config"), e );
                return false;
            }

            return true;
        }
        return false;
    }

    public void dispose( StepMetaInterface smi, StepDataInterface sdi ) {
        meta = (SNZRestClientPluginMeta) smi;
        data = (SNZRestClientPluginData) sdi;
        data.headerNames = null;
        data.indexOfHeaderFields = null;
        data.paramNames = null;

        super.dispose( smi, sdi );
    }
}
